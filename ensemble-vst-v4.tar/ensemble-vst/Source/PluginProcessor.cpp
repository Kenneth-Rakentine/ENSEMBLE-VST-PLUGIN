// PluginProcessor.cpp — ENSEMBLE VST
#include "PluginProcessor.h"
#include "PluginEditor.h"

EnsembleAudioProcessor::EnsembleAudioProcessor()
    : AudioProcessor(BusesProperties()
          .withInput("Input", juce::AudioChannelSet::stereo(), true)
          .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "ENSEMBLE_PARAMS", createParameterLayout())
{}

EnsembleAudioProcessor::~EnsembleAudioProcessor() {}

juce::AudioProcessorValueTreeState::ParameterLayout
EnsembleAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;

    // Weave Engine
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ID_BLEND,1}, "Blend",
        juce::NormalisableRange<float>(0.f,1.f,0.01f), 0.55f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ID_TENSION,1}, "Tension",
        juce::NormalisableRange<float>(0.f,1.f,0.01f), 0.40f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ID_TEXTURE,1}, "Texture",
        juce::NormalisableRange<float>(0.f,1.f,0.01f), 0.60f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ID_EVOLVE,1}, "Evolve",
        juce::NormalisableRange<float>(0.f,1.f,0.01f), 0.75f));

    // Mix
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ID_PERSIST,1}, "Persist",
        juce::NormalisableRange<float>(0.5f,0.99f,0.01f), 0.93f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ID_INPUT,1}, "Input",
        juce::NormalisableRange<float>(0.f,1.f,0.01f), 0.85f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ID_DRY,1}, "Dry",
        juce::NormalisableRange<float>(0.f,1.f,0.01f), 0.10f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ID_OUTPUT,1}, "Output",
        juce::NormalisableRange<float>(0.f,1.f,0.01f), 0.80f));

    // EQ wet
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ID_EQ_WET,1}, "EQ Mix",
        juce::NormalisableRange<float>(0.f,1.f,0.01f), 0.0f));

    // 12 EQ bands (-12 to +12 dB)
    const char* eqLabels[12] = {
        "60Hz","120Hz","250Hz","500Hz","1kHz","2kHz",
        "3kHz","4kHz","6kHz","8kHz","12kHz","16kHz"
    };
    for (int b = 0; b < 12; ++b) {
        p.push_back(std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID{ID_EQ[b],1}, eqLabels[b],
            juce::NormalisableRange<float>(-12.f,12.f,0.1f), 0.f));
    }

    // Bandpass filter
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ID_BP_FREQ,1}, "BP Freq",
        juce::NormalisableRange<float>(40.f,16000.f,1.f,0.3f), 1000.f));
    p.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{ID_BP_ENABLED,1}, "BP On", false));

    return { p.begin(), p.end() };
}

void EnsembleAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{
    dsp.prepare(sampleRate, samplesPerBlock);
}

void EnsembleAudioProcessor::releaseResources() {}

void EnsembleAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    // Handle clear request from UI
    if (clearRequested.exchange(false))
        dsp.clearBuffers();

    auto totalIn  = getTotalNumInputChannels();
    auto totalOut = getTotalNumOutputChannels();
    for (auto i = totalIn; i < totalOut; ++i)
        buffer.clear(i, 0, buffer.getNumSamples());

    // Read parameters
    auto& dp = dsp.getParams();
    dp.blend     = apvts.getRawParameterValue(ID_BLEND)->load();
    dp.tension   = apvts.getRawParameterValue(ID_TENSION)->load();
    dp.texture   = apvts.getRawParameterValue(ID_TEXTURE)->load();
    dp.evolve    = apvts.getRawParameterValue(ID_EVOLVE)->load();
    dp.preLevel  = apvts.getRawParameterValue(ID_PERSIST)->load();
    dp.inputGain = apvts.getRawParameterValue(ID_INPUT)->load();
    dp.dryLevel  = apvts.getRawParameterValue(ID_DRY)->load();
    dp.outputGain= apvts.getRawParameterValue(ID_OUTPUT)->load();

    // EQ
    float eqWet = apvts.getRawParameterValue(ID_EQ_WET)->load();
    auto& eq = dsp.getEQ();
    eq.enabled = eqWet > 0.01f;
    eq.wet = eqWet;
    for (int b = 0; b < 12; ++b)
        eq.setBandGain(b, apvts.getRawParameterValue(ID_EQ[b])->load());

    // Bandpass filter
    auto& bp = dsp.getBPFilter();
    bp.enabled = apvts.getRawParameterValue(ID_BP_ENABLED)->load() > 0.5f;
    bp.setFreq(apvts.getRawParameterValue(ID_BP_FREQ)->load());

    // Process
    int n = buffer.getNumSamples();
    if (totalIn >= 2) {
        dsp.processBlock(buffer.getWritePointer(0), buffer.getWritePointer(1), n);
    } else if (totalIn == 1 && totalOut >= 2) {
        float* L = buffer.getWritePointer(0);
        float* R = buffer.getWritePointer(1);
        std::memcpy(R, L, sizeof(float) * n);
        dsp.processBlock(L, R, n);
    }
}

juce::AudioProcessorEditor* EnsembleAudioProcessor::createEditor()
{
    return new EnsembleAudioProcessorEditor(*this);
}

void EnsembleAudioProcessor::getStateInformation(juce::MemoryBlock& dest)
{
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, dest);
}

void EnsembleAudioProcessor::setStateInformation(const void* data, int size)
{
    auto xml = getXmlFromBinary(data, size);
    if (xml && xml->hasTagName(apvts.state.getType()))
        apvts.replaceState(juce::ValueTree::fromXml(*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new EnsembleAudioProcessor();
}
