// BandpassFilter.h
// ENSEMBLE VST — Simple bandpass for cleanup. On/off + frequency knob.
// Gentle Q (1.2), not dramatic — just removes mud or harsh treble.

#pragma once
#include "Biquad.h"
#include <cmath>
#include <algorithm>

class BandpassFilter {
public:
    void prepare(float sampleRate) {
        sr = sampleRate;
        updateCoeffs();
    }

    void setFreq(float hz) {
        freq = std::max(40.f, std::min(hz, sr * 0.45f));
        updateCoeffs();
    }

    void process(float& left, float& right) {
        if (!enabled) return;
        left  = filterL.process(left);
        right = filterR.process(right);
    }

    void reset() { filterL.reset(); filterR.reset(); }

    bool enabled = false;
    float freq = 1000.f;

private:
    float sr = 48000.f;
    Biquad filterL, filterR;

    void updateCoeffs() {
        float f = std::min(freq, sr * 0.45f);
        filterL.setParams(Biquad::BandPass, f, 1.2f, sr);
        filterR.setParams(Biquad::BandPass, f, 1.2f, sr);
    }
};
