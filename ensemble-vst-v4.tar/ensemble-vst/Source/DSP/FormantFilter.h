// FormantFilter.h
// ENSEMBLE VST — 3-band formant filter for MASS voice processing
// Centers drift via LFO to create vowel-like orchestral quality.
// Inspired by the spectral analysis target: "intensely tonal, NOT noise"

#pragma once
#include "Biquad.h"
#include <cmath>

class FormantFilter {
public:
    static constexpr int NUM_BANDS = 3;

    void prepare(float sampleRate) {
        sr = sampleRate;
        for (int b = 0; b < NUM_BANDS; ++b) {
            bandsL[b].reset();
            bandsR[b].reset();
        }
    }

    /// Process one stereo sample through the formant bank.
    /// modulation: 0-1 LFO value that shifts formant centers.
    /// tension: 0-1 controls Q (higher = more resonant, more stressed).
    /// wetDry: 0-1 blend of filtered vs dry (evolves with stage).
    void process(float& left, float& right,
                 float modulation, float tension, float wetDry) {
        // Formant center frequencies drift with modulation
        // Base centers: ~400 Hz (chest), ~1200 Hz (throat), ~2400 Hz (head)
        float centers[NUM_BANDS] = {
            350.f + modulation * 150.f,   // 350-500 Hz
            1000.f + modulation * 500.f,  // 1000-1500 Hz
            2100.f + modulation * 800.f   // 2100-2900 Hz
        };

        // Q increases with tension: relaxed (0.3) to stressed (2.5)
        float Q = 0.3f + tension * 2.2f;

        // Update coefficients (could be done at control rate for efficiency)
        for (int b = 0; b < NUM_BANDS; ++b) {
            bandsL[b].setParams(Biquad::BandPass, centers[b], Q, sr);
            bandsR[b].setParams(Biquad::BandPass, centers[b], Q, sr);
        }

        // Sum the three formant bands
        float filtL = 0.f, filtR = 0.f;
        for (int b = 0; b < NUM_BANDS; ++b) {
            filtL += bandsL[b].process(left)  * gains[b];
            filtR += bandsR[b].process(right) * gains[b];
        }

        // Wet/dry mix
        left  = left  * (1.f - wetDry) + filtL * wetDry;
        right = right * (1.f - wetDry) + filtR * wetDry;
    }

    void reset() {
        for (int b = 0; b < NUM_BANDS; ++b) {
            bandsL[b].reset();
            bandsR[b].reset();
        }
    }

private:
    float sr = 48000.f;
    Biquad bandsL[NUM_BANDS];
    Biquad bandsR[NUM_BANDS];

    // Per-band gains: chest louder, head quieter (natural spectral rolloff)
    static constexpr float gains[NUM_BANDS] = { 1.0f, 0.7f, 0.45f };
};
