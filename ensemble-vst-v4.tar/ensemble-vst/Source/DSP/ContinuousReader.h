// ContinuousReader.h
// ENSEMBLE VST — Single continuous weave voice
// Reads perpetually from the circular buffer at a drifting offset/rate.
// The pressure field texture emerges from 8 of these running simultaneously.

#pragma once
#include "CircularBuffer.h"
#include <cmath>
#include <algorithm>

class ContinuousReader {
public:
    /// Configure this voice.
    /// offsetSeconds: how far behind write head this voice reads (base)
    /// driftScale:    how much the Drift LFO affects offset (0-1)
    /// panBase:       base stereo position (-1 to 1), golden ratio assigned
    /// voiceIndex:    which voice (0-7), used for phase offsets
    void init(double offsetSeconds, float driftScale, float panBase, int voiceIndex) {
        baseOffset = offsetSeconds;
        driftAmount = driftScale;
        pan = panBase;
        index = voiceIndex;

        // Unique phase offsets per voice for decorrelation
        phaseOffset = voiceIndex * 1.618033988749895;
    }

    /// Process one sample. Call once per sample in the audio callback.
    /// Writes into outL/outR (additive — caller zeroes before first voice).
    void process(const CircularBuffer& buf, float& outL, float& outR,
                 // LFO values (pre-computed per block or per sample)
                 float glacierUni,   // 0-1, controls level + window
                 float tideUni,      // 0-1, controls level swell
                 float driftBi,      // -1 to 1, controls offset drift
                 float swirlBi,      // -1 to 1, controls pan drift
                 float shimmerUni,   // 0-1, controls filter cutoff
                 float rippleBi,     // -1 to 1, controls pitch drift
                 // Parameters
                 float blend,        // 0=DUST-biased, 1=MASS-biased
                 float textureAmt,   // overall weave amount (0-1)
                 float inputAmp      // current input amplitude (0-1)
    ) {
        if (buf.getSize() < 100) return;
        double sr = buf.getSampleRate();

        // --- OFFSET: where in the buffer we're reading ---
        // Base offset modulated by Drift LFO
        double offset = baseOffset * (1.0 + driftBi * driftAmount * 0.4);
        offset = std::max(0.1, offset); // never read write head directly

        // --- LOOP WINDOW: how long our loop region is ---
        // Glacier LFO breathes the window open and closed.
        // Blend biases: high blend = longer windows (MASS), low = shorter
        double windowBase = 0.5 + blend * 3.5; // 0.5s to 4.0s
        double window = windowBase * (0.6 + glacierUni * 0.8); // breathe 60-140%
        double windowSamples = window * sr;

        // --- READ POSITION ---
        double readPos = buf.secondsToPos(offset);

        // Advance our internal phase through the loop window
        // Rate: 1.0 +/- ripple (microtonal drift, +/-5 cents = +/-0.003)
        double rateCents = rippleBi * 5.0; // +/-5 cents
        double rate = std::pow(2.0, rateCents / 1200.0);
        readPhase += rate;

        // Wrap within loop window with crossfade
        if (readPhase >= windowSamples) {
            readPhase -= windowSamples;
            crossfadePhase = crossfadeSamples; // start crossfade
        }

        double samplePos = readPos + readPhase;

        // Stereo decorrelation: L and R read from slightly offset positions
        // Like players in a real ensemble sitting in different positions.
        // Offset scales with voice index for maximum spread.
        double stereoOffsetSamples = (index + 1) * 37.0; // 37-296 samples (~0.7-6ms at 48kHz)

        // --- CROSSFADE at loop boundary ---
        float sample_L, sample_R;
        if (crossfadePhase > 0) {
            float cf = static_cast<float>(crossfadePhase) / crossfadeSamples;
            float oldL, oldR, newL, newR;
            float tmpL2, tmpR2;
            buf.readCubic(samplePos + windowSamples, oldL, tmpR2);
            buf.readCubic(samplePos + windowSamples + stereoOffsetSamples, tmpL2, oldR);
            buf.readCubic(samplePos, newL, tmpR2);
            buf.readCubic(samplePos + stereoOffsetSamples, tmpL2, newR);
            sample_L = oldL * cf + newL * (1.f - cf);
            sample_R = oldR * cf + newR * (1.f - cf);
            crossfadePhase -= 1.0;
        } else {
            float tmpR2, tmpL2;
            buf.readCubic(samplePos, sample_L, tmpR2);
            buf.readCubic(samplePos + stereoOffsetSamples, tmpL2, sample_R);
        }

        // --- ONE-POLE LP FILTER (with stereo offset for decorrelation) ---
        float cutoffHz = 2000.f + shimmerUni * 4000.f + index * 300.f;
        cutoffHz = std::min(cutoffHz, static_cast<float>(sr * 0.45));
        float dt_f = 1.f / static_cast<float>(sr);

        // Slightly different cutoff per channel (+/- 8%)
        float cutoffL = cutoffHz * (1.0f - 0.08f);
        float cutoffR = cutoffHz * (1.0f + 0.08f);

        float rcL = 1.f / (2.f * 3.14159265f * cutoffL);
        float alphaL = dt_f / (rcL + dt_f);
        filterL += alphaL * (sample_L - filterL);

        float rcR = 1.f / (2.f * 3.14159265f * cutoffR);
        float alphaR = dt_f / (rcR + dt_f);
        filterR += alphaR * (sample_R - filterR);

        // Mix filtered and dry based on blend (more MASS = more filtered)
        float filtMix = 0.3f + blend * 0.4f;
        sample_L = sample_L * (1.f - filtMix) + filterL * filtMix;
        sample_R = sample_R * (1.f - filtMix) + filterR * filtMix;

        // --- LEVEL ---
        // Glacier (slow breathing) x Tide (medium swell) x input reactivity
        float level = 0.3f + glacierUni * 0.4f + tideUni * 0.2f;
        level += inputAmp * 0.15f; // louder input = louder texture
        level *= textureAmt;
        level = std::min(level, 1.0f);

        sample_L *= level;
        sample_R *= level;

        // --- PAN ---
        // Golden ratio base + Swirl LFO drift
        float panFinal = pan + swirlBi * 0.6f;
        panFinal = std::max(-1.f, std::min(1.f, panFinal));

        // Constant-power panning
        float panAngle = (panFinal + 1.f) * 0.25f * 3.14159265f; // 0 to pi/2
        float panL = std::cos(panAngle);
        float panR = std::sin(panAngle);

        outL += sample_L * panL;
        outR += sample_R * panR;
    }

    void reset() {
        readPhase = 0.0;
        crossfadePhase = 0.0;
        filterL = filterR = 0.f;
    }

private:
    double baseOffset = 2.0;     // seconds behind write head
    float driftAmount = 0.5f;
    float pan = 0.f;
    int index = 0;
    double phaseOffset = 0.0;

    // Playback state
    double readPhase = 0.0;      // current position within loop window
    double crossfadePhase = 0.0; // remaining crossfade samples
    static constexpr double crossfadeSamples = 512.0; // ~10ms at 48kHz

    // Filter state
    float filterL = 0.f;
    float filterR = 0.f;
};
