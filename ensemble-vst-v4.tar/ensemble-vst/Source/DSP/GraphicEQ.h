// GraphicEQ.h
// ENSEMBLE VST — 12-band graphic EQ / filterbank
// Per-band gain (-12 to +12 dB), overall wet/dry mix.
// Fixed log-spaced centers: 60, 120, 250, 500, 1k, 2k, 3k, 4k, 6k, 8k, 12k, 16k Hz

#pragma once
#include "Biquad.h"
#include <cmath>
#include <algorithm>

class GraphicEQ {
public:
    static constexpr int NUM_BANDS = 12;

    // Fixed center frequencies
    static constexpr float CENTERS[NUM_BANDS] = {
        60.f, 120.f, 250.f, 500.f,
        1000.f, 2000.f, 3000.f, 4000.f,
        6000.f, 8000.f, 12000.f, 16000.f
    };

    void prepare(float sampleRate) {
        sr = sampleRate;
        for (int b = 0; b < NUM_BANDS; ++b) {
            bandGainDb[b] = 0.f; // flat
            updateBand(b);
        }
    }

    void setBandGain(int band, float dB) {
        if (band < 0 || band >= NUM_BANDS) return;
        dB = std::max(-12.f, std::min(12.f, dB));
        if (std::abs(bandGainDb[band] - dB) > 0.01f) {
            bandGainDb[band] = dB;
            updateBand(band);
        }
    }

    float getBandGain(int band) const {
        return (band >= 0 && band < NUM_BANDS) ? bandGainDb[band] : 0.f;
    }

    /// Process one stereo sample in-place.
    void process(float& left, float& right) {
        if (!enabled || wet < 0.001f) return;

        float eqL = left, eqR = right;
        // Series peak EQ: each band boosts/cuts its frequency
        for (int b = 0; b < NUM_BANDS; ++b) {
            if (std::abs(bandGainDb[b]) > 0.1f) { // skip flat bands
                eqL = bandsL[b].process(eqL);
                eqR = bandsR[b].process(eqR);
            }
        }

        left  = left  * (1.f - wet) + eqL * wet;
        right = right * (1.f - wet) + eqR * wet;
    }

    void reset() {
        for (int b = 0; b < NUM_BANDS; ++b) {
            bandsL[b].reset();
            bandsR[b].reset();
        }
    }

    bool enabled = false;
    float wet = 1.0f;

private:
    float sr = 48000.f;
    float bandGainDb[NUM_BANDS] = {};
    Biquad bandsL[NUM_BANDS], bandsR[NUM_BANDS];

    void updateBand(int b) {
        float freq = CENTERS[b];
        if (freq > sr * 0.45f) freq = sr * 0.45f;
        // Q of ~1.4 gives smooth overlap between bands for 12-band graphic EQ
        float Q = 1.4f;
        bandsL[b].setParams(Biquad::Peak, freq, Q, sr, bandGainDb[b]);
        bandsR[b].setParams(Biquad::Peak, freq, Q, sr, bandGainDb[b]);
    }
};
