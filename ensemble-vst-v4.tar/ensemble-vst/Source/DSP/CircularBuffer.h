// CircularBuffer.h
// ENSEMBLE VST — Stereo circular buffer with interpolated reads
// Accumulative recording with configurable persistence (pre-level).
// Old material persists beneath new input, building density over time.

#pragma once
#include <cmath>
#include <cstring>
#include <algorithm>
#include <cassert>

class CircularBuffer {
public:
    CircularBuffer() = default;
    ~CircularBuffer() { free(); }

    // Non-copyable, movable
    CircularBuffer(const CircularBuffer&) = delete;
    CircularBuffer& operator=(const CircularBuffer&) = delete;
    CircularBuffer(CircularBuffer&& o) noexcept
        : bufL(o.bufL), bufR(o.bufR), bufSize(o.bufSize),
          writePos(o.writePos), sampleRate_(o.sampleRate_) {
        o.bufL = o.bufR = nullptr;
        o.bufSize = 0;
    }

    /// Allocate buffer for given duration at given sample rate.
    void allocate(double sampleRate, double seconds) {
        free();
        sampleRate_ = sampleRate;
        bufSize = static_cast<int>(sampleRate * seconds) + 1;
        bufL = new float[bufSize]();
        bufR = new float[bufSize]();
        writePos = 0;
    }

    void free() {
        delete[] bufL; bufL = nullptr;
        delete[] bufR; bufR = nullptr;
        bufSize = 0;
    }

    /// Write one stereo sample. Applies pre-level feedback (accumulation).
    /// pre = 0: replace entirely. pre = 0.93: old material persists strongly.
    void write(float left, float right, float preLevel) {
        if (!bufL) return;
        bufL[writePos] = left + bufL[writePos] * preLevel;
        bufR[writePos] = right + bufR[writePos] * preLevel;
        writePos = (writePos + 1) % bufSize;
    }

    /// Read at fractional position using cubic Hermite interpolation.
    /// pos is in samples (fractional). Wraps automatically.
    void readCubic(double pos, float& outL, float& outR) const {
        if (!bufL || bufSize < 4) { outL = outR = 0.f; return; }

        // Wrap to buffer range
        double wrapped = fmod(pos, static_cast<double>(bufSize));
        if (wrapped < 0.0) wrapped += bufSize;

        int i1 = static_cast<int>(wrapped);
        float frac = static_cast<float>(wrapped - i1);

        int i0 = (i1 - 1 + bufSize) % bufSize;
        i1 = i1 % bufSize;
        int i2 = (i1 + 1) % bufSize;
        int i3 = (i1 + 2) % bufSize;

        outL = hermite(frac, bufL[i0], bufL[i1], bufL[i2], bufL[i3]);
        outR = hermite(frac, bufR[i0], bufR[i1], bufR[i2], bufR[i3]);
    }

    /// Read with linear interpolation (cheaper, good for DUST grains).
    void readLinear(double pos, float& outL, float& outR) const {
        if (!bufL || bufSize < 2) { outL = outR = 0.f; return; }

        double wrapped = fmod(pos, static_cast<double>(bufSize));
        if (wrapped < 0.0) wrapped += bufSize;

        int i0 = static_cast<int>(wrapped) % bufSize;
        int i1 = (i0 + 1) % bufSize;
        float frac = static_cast<float>(wrapped - static_cast<int>(wrapped));

        outL = bufL[i0] + frac * (bufL[i1] - bufL[i0]);
        outR = bufR[i0] + frac * (bufR[i1] - bufR[i0]);
    }

    /// Zero entire buffer.
    void clear() {
        if (bufL) std::memset(bufL, 0, sizeof(float) * bufSize);
        if (bufR) std::memset(bufR, 0, sizeof(float) * bufSize);
        writePos = 0;
    }

    int getWritePos() const { return writePos; }
    int getSize() const { return bufSize; }
    double getSampleRate() const { return sampleRate_; }

    /// Convert seconds-behind-write-head to absolute sample position.
    double secondsToPos(double secondsBehind) const {
        double samplesBehind = secondsBehind * sampleRate_;
        double pos = static_cast<double>(writePos) - samplesBehind;
        if (pos < 0.0) pos += bufSize;
        return pos;
    }

private:
    float* bufL = nullptr;
    float* bufR = nullptr;
    int bufSize = 0;
    int writePos = 0;
    double sampleRate_ = 48000.0;

    /// Cubic Hermite interpolation (4-point, 3rd order).
    static float hermite(float frac, float y0, float y1, float y2, float y3) {
        float c0 = y1;
        float c1 = 0.5f * (y2 - y0);
        float c2 = y0 - 2.5f * y1 + 2.f * y2 - 0.5f * y3;
        float c3 = 0.5f * (y3 - y0) + 1.5f * (y1 - y2);
        return ((c3 * frac + c2) * frac + c1) * frac + c0;
    }
};
