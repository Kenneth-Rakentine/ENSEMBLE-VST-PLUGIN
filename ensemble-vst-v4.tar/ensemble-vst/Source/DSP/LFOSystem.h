// LFOSystem.h
// ENSEMBLE VST — Six incommensurate LFOs for organic modulation
// Rates chosen so no two are integer multiples: texture never cycles.

#pragma once
#include <cmath>

class LFOSystem {
public:
    // LFO indices
    enum ID {
        Glacier = 0,  // ~180s — macro breathing, voice levels, window size
        Tide,         // ~73s  — density swell, level modulation
        Drift,        // ~47s  — buffer offset / scan position
        Swirl,        // ~29s  — pan position movement
        Shimmer,      // ~19s  — filter cutoff modulation
        Ripple,       // ~11s  — micro pitch drift (rate modulation)
        Count
    };

    void reset() {
        for (int i = 0; i < Count; ++i)
            phase[i] = 0.0;
    }

    /// Advance all LFOs by dt seconds.
    void update(double dt) {
        constexpr double TAU = 6.283185307179586;
        for (int i = 0; i < Count; ++i) {
            phase[i] += rates[i] * dt;
            // Keep phase bounded (avoid precision loss over hours)
            if (phase[i] > TAU * 1000.0)
                phase[i] -= TAU * 1000.0;
        }
    }

    /// Get current value of LFO i in range [0, 1] (unipolar).
    float uni(int i) const {
        return static_cast<float>(std::sin(phase[i]) * 0.5 + 0.5);
    }

    /// Get current value of LFO i in range [-1, 1] (bipolar).
    float bi(int i) const {
        return static_cast<float>(std::sin(phase[i]));
    }

    /// Get value scaled to [lo, hi].
    float range(int i, float lo, float hi) const {
        return lo + uni(i) * (hi - lo);
    }

private:
    double phase[Count] = {};

    // Rates in radians/second.
    // Chosen for incommensurability: no integer multiples.
    //   Glacier: 2*pi / 180 ≈ 0.0349
    //   Tide:    2*pi / 73  ≈ 0.0861
    //   Drift:   2*pi / 47  ≈ 0.1337
    //   Swirl:   2*pi / 29  ≈ 0.2167
    //   Shimmer: 2*pi / 19  ≈ 0.3307
    //   Ripple:  2*pi / 11  ≈ 0.5712
    static constexpr double rates[Count] = {
        0.034907, // Glacier  ~180s cycle
        0.086057, // Tide     ~73s  cycle
        0.133686, // Drift    ~47s  cycle
        0.216662, // Swirl    ~29s  cycle
        0.330693, // Shimmer  ~19s  cycle
        0.571199  // Ripple   ~11s  cycle
    };
};
