// GrainEnvelope.h
// ENSEMBLE VST — Grain envelope generator
// Quasi-gaussian shape: soft rounded attack, brief sustain, gentle decay.
// NOT harsh expodec — that causes unpleasant choppy clicks on short grains.

#pragma once
#include <cmath>

class GrainEnvelope {
public:
    /// Start a new grain.
    /// attackMs/releaseMs: envelope times
    /// sustainLevel: sustain amplitude (0-1)
    void trigger(float attackMs, float releaseMs, float sustainLevel, float sampleRate) {
        sr = sampleRate;
        float attackSamples = attackMs * 0.001f * sampleRate;
        float releaseSamples = releaseMs * 0.001f * sampleRate;

        // Minimum 4 samples per stage to avoid divide-by-zero
        attackInc = (attackSamples > 4.f) ? (1.f / attackSamples) : 0.25f;
        releaseInc = (releaseSamples > 4.f) ? (1.f / releaseSamples) : 0.25f;
        sustain = sustainLevel;
        phase = 0.f;
        stage = Attack;
        value = 0.f;
    }

    /// Trigger with grain-length-based auto envelope.
    /// grainMs: total grain duration. Envelope uses ~15% attack, ~25% release.
    void triggerAuto(float grainMs, float sampleRate) {
        float attackMs  = grainMs * 0.15f; // 15% attack
        float releaseMs = grainMs * 0.25f; // 25% release
        trigger(attackMs, releaseMs, 1.0f, sampleRate);

        // Set total grain duration for auto-release
        float totalSamples = grainMs * 0.001f * sampleRate;
        float attackSamples = attackMs * 0.001f * sampleRate;
        float releaseSamples = releaseMs * 0.001f * sampleRate;
        sustainSamples = totalSamples - attackSamples - releaseSamples;
        if (sustainSamples < 0.f) sustainSamples = 0.f;
        sustainCounter = 0.f;
        autoRelease = true;
    }

    /// Get next envelope value. Returns 0 when finished.
    float next() {
        switch (stage) {
        case Attack:
            phase += attackInc;
            // Raised cosine attack (smoother than linear)
            value = 0.5f - 0.5f * std::cos(phase * 3.14159265f);
            if (phase >= 1.f) {
                value = 1.f;
                stage = Sustain;
                sustainCounter = 0.f;
            }
            break;

        case Sustain:
            value = sustain;
            if (autoRelease) {
                sustainCounter += 1.f;
                if (sustainCounter >= sustainSamples) {
                    stage = Release;
                    phase = 0.f;
                }
            }
            break;

        case Release:
            phase += releaseInc;
            // Raised cosine release
            value = sustain * (0.5f + 0.5f * std::cos(phase * 3.14159265f));
            if (phase >= 1.f) {
                value = 0.f;
                stage = Done;
            }
            break;

        case Done:
            value = 0.f;
            break;
        }

        return value;
    }

    /// Begin release stage (for voice stealing / manual release).
    void startRelease() {
        if (stage == Attack || stage == Sustain) {
            sustain = value; // release from current level
            stage = Release;
            phase = 0.f;
        }
    }

    bool isDone() const { return stage == Done; }
    bool isActive() const { return stage != Done; }
    float getValue() const { return value; }

private:
    enum Stage { Attack, Sustain, Release, Done };
    Stage stage = Done;

    float sr = 48000.f;
    float attackInc = 0.01f;
    float releaseInc = 0.01f;
    float sustain = 1.f;
    float phase = 0.f;
    float value = 0.f;

    // Auto-release support
    bool autoRelease = false;
    float sustainSamples = 0.f;
    float sustainCounter = 0.f;
};
