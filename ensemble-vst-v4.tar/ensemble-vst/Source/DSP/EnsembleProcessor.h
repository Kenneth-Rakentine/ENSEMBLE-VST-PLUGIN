// EnsembleProcessor.h
// ENSEMBLE VST — Top-level audio processor
// Weave Engine → MASS/DUST grains → GraphicEQ → BandpassFilter → Limiter

#pragma once
#include "WeaveEngine.h"
#include "GrainLayer.h"
#include "GraphicEQ.h"
#include "BandpassFilter.h"
#include "SafetyLimiter.h"
#include <cmath>
#include <algorithm>
#include <vector>

struct EnsembleParams {
    // --- Weave Engine ---
    float blend      = 0.55f;  // 0=DUST-biased, 1=MASS-biased
    float tension    = 0.40f;  // comb filter stress
    float texture    = 0.60f;  // weave output level
    float evolve     = 0.75f;  // autonomous modulation depth

    // --- Buffer ---
    float preLevel   = 0.93f;  // buffer persistence / accumulation
    float inputGain  = 0.85f;  // input level to buffer
    float dryLevel   = 0.10f;  // pass-through dry signal

    // --- EQ ---
    bool eqEnabled   = false;
    float eqWet      = 1.0f;

    // --- Bandpass Filter ---
    bool bpEnabled   = false;
    float bpFreq     = 1000.f;  // Hz

    // --- Output ---
    float outputGain = 0.80f;

    // --- State ---
    bool active      = true;
};

class EnsembleProcessor {
public:
    void prepare(double sampleRate, int maxBlockSize) {
        sr = sampleRate;
        weave.prepare(sampleRate, 60.0);
        grains.prepare(static_cast<float>(sampleRate));
        eq.prepare(static_cast<float>(sampleRate));
        bpFilter.prepare(static_cast<float>(sampleRate));
        limiter.setSampleRate(sampleRate);
        limiter.reset();

        tmpL.resize(maxBlockSize, 0.f);
        tmpR.resize(maxBlockSize, 0.f);
    }

    void processBlock(float* left, float* right, int numSamples) {
        if (!params.active) return;

        // Copy input for dry mix
        for (int i = 0; i < numSamples; ++i) {
            tmpL[i] = left[i];
            tmpR[i] = right[i];
        }

        // --- Weave Engine ---
        weave.processBlock(
            tmpL.data(), tmpR.data(),
            left, right,
            numSamples,
            params.blend, params.tension, params.texture,
            params.evolve, params.preLevel, params.inputGain,
            params.dryLevel
        );

        // --- MASS + DUST Grain Layers ---
        {
            const auto& lfo = weave.getLFOs();
            const auto& buf = weave.getBuffer();
            float inputEnv = weave.getInputEnvelope();

            for (int s = 0; s < numSamples; ++s) {
                float grainL = 0.f, grainR = 0.f;
                grains.process(
                    buf, grainL, grainR,
                    lfo.uni(LFOSystem::Glacier),
                    lfo.uni(LFOSystem::Tide),
                    lfo.bi(LFOSystem::Swirl),
                    lfo.uni(LFOSystem::Shimmer),
                    params.blend, params.tension, params.evolve,
                    std::min(inputEnv, 1.0f)
                );
                left[s]  += grainL;
                right[s] += grainR;

                // --- Graphic EQ ---
                eq.process(left[s], right[s]);

                // --- Bandpass Filter ---
                bpFilter.process(left[s], right[s]);
            }
        }

        // --- Safety Limiter ---
        limiter.processBlock(left, right, numSamples);

        // --- Output Gain ---
        for (int i = 0; i < numSamples; ++i) {
            left[i]  *= params.outputGain;
            right[i] *= params.outputGain;
        }
    }

    /// Clear all buffers — the CLEAR button
    void clearBuffers() {
        weave.clear();
        grains.reset();
        eq.reset();
        bpFilter.reset();
        limiter.reset();
    }

    // Access
    WeaveEngine& getWeave() { return weave; }
    GrainLayer& getGrains() { return grains; }
    GraphicEQ& getEQ() { return eq; }
    BandpassFilter& getBPFilter() { return bpFilter; }
    EnsembleParams& getParams() { return params; }
    const EnsembleParams& getParams() const { return params; }
    float getInputLevel() const { return weave.getInputEnvelope(); }

private:
    double sr = 48000.0;
    WeaveEngine weave;
    GrainLayer grains;
    GraphicEQ eq;
    BandpassFilter bpFilter;
    SafetyLimiter limiter;
    EnsembleParams params;
    std::vector<float> tmpL, tmpR;
};
