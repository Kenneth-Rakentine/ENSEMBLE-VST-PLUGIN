// Biquad.h
// ENSEMBLE VST — Standard biquad filter (2nd order IIR)
// Used by: FormantFilter, CombFilter, Vocoder, Filterbank
// Cookbook coefficients from Robert Bristow-Johnson.

#pragma once
#include <cmath>

class Biquad {
public:
    enum Type { LowPass, HighPass, BandPass, Notch, Peak };

    void reset() {
        x1 = x2 = y1 = y2 = 0.f;
    }

    /// Set filter coefficients. Call when freq/Q/gain change.
    void setParams(Type type, float freq, float Q, float sampleRate, float gainDb = 0.f) {
        float w0 = 2.f * 3.14159265f * freq / sampleRate;
        float cosw0 = std::cos(w0);
        float sinw0 = std::sin(w0);
        float alpha = sinw0 / (2.f * Q);

        float b0 = 0.f, b1 = 0.f, b2 = 0.f, a0 = 1.f, a1 = 0.f, a2 = 0.f;

        switch (type) {
        case LowPass:
            b0 = (1.f - cosw0) * 0.5f;
            b1 = 1.f - cosw0;
            b2 = (1.f - cosw0) * 0.5f;
            a0 = 1.f + alpha;
            a1 = -2.f * cosw0;
            a2 = 1.f - alpha;
            break;
        case HighPass:
            b0 = (1.f + cosw0) * 0.5f;
            b1 = -(1.f + cosw0);
            b2 = (1.f + cosw0) * 0.5f;
            a0 = 1.f + alpha;
            a1 = -2.f * cosw0;
            a2 = 1.f - alpha;
            break;
        case BandPass:
            b0 = alpha;
            b1 = 0.f;
            b2 = -alpha;
            a0 = 1.f + alpha;
            a1 = -2.f * cosw0;
            a2 = 1.f - alpha;
            break;
        case Notch:
            b0 = 1.f;
            b1 = -2.f * cosw0;
            b2 = 1.f;
            a0 = 1.f + alpha;
            a1 = -2.f * cosw0;
            a2 = 1.f - alpha;
            break;
        case Peak: {
            float A = std::pow(10.f, gainDb / 40.f);
            b0 = 1.f + alpha * A;
            b1 = -2.f * cosw0;
            b2 = 1.f - alpha * A;
            a0 = 1.f + alpha / A;
            a1 = -2.f * cosw0;
            a2 = 1.f - alpha / A;
            break;
        }
        }

        // Normalize
        float inv_a0 = 1.f / a0;
        cb0 = b0 * inv_a0;
        cb1 = b1 * inv_a0;
        cb2 = b2 * inv_a0;
        ca1 = a1 * inv_a0;
        ca2 = a2 * inv_a0;
    }

    /// Process one sample (Direct Form II Transposed).
    float process(float in) {
        float out = cb0 * in + cb1 * x1 + cb2 * x2 - ca1 * y1 - ca2 * y2;
        x2 = x1; x1 = in;
        y2 = y1; y1 = out;
        return out;
    }

private:
    float cb0 = 1.f, cb1 = 0.f, cb2 = 0.f;
    float ca1 = 0.f, ca2 = 0.f;
    float x1 = 0.f, x2 = 0.f;
    float y1 = 0.f, y2 = 0.f;
};
