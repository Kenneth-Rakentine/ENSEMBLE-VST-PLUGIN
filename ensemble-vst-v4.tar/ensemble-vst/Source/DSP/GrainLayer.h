// GrainLayer.h
// ENSEMBLE VST — Phase 2: MASS + DUST grain layers
//
// MASS: 4 voices, 3-6s grains, slow envelopes (150-400ms attack),
//   formant BPF filtering, comb tension, glissando, occasional reverse.
//   Creates the "bed" / "fog" / smeared orchestral foundation.
//
// DUST: 4 voices, 30-120ms grains, soft fast envelopes (15-30ms),
//   stochastic timing (Dust.kr equivalent), HP for sul ponticello,
//   Phantom Limb dispersion (6 delay taps, progressive darkening).
//   Creates surface friction, pointillism, col legno texture.

#pragma once
#include "CircularBuffer.h"
#include "GrainEnvelope.h"
#include "FormantFilter.h"
#include "CombFilter.h"
#include "Biquad.h"
#include "LFOSystem.h"
#include <cmath>
#include <cstring>
#include <cstdint>
#include <algorithm>

// ---- LFSR for pseudo-random in audio code (deterministic, no system calls) ----
struct LFSR {
    uint32_t state = 0xACE1u;

    void seed(uint32_t s) { state = s ? s : 0xACE1u; }

    uint32_t step() {
        uint32_t bit = ((state >> 0) ^ (state >> 2) ^ (state >> 3) ^ (state >> 5)) & 1;
        state = (state >> 1) | (bit << 15);
        return state;
    }

    /// Returns 0.0 to 1.0
    float nextFloat() {
        return static_cast<float>(step()) / 65535.f;
    }

    /// Returns lo to hi
    float nextRange(float lo, float hi) {
        return lo + nextFloat() * (hi - lo);
    }
};

// ---- Single MASS voice ----
struct MassVoice {
    GrainEnvelope env;
    FormantFilter formant;
    CombFilter comb;

    double readPos = 0.0;
    double readRate = 1.0;     // ~1.0 +/- glissando
    float panL = 0.707f, panR = 0.707f;
    float level = 0.4f;
    bool reverse = false;
    bool active = false;
    float grainLengthSec = 3.0f;
    float glissRate = 0.0f;    // cents/second of gliss

    void prepare(float sr) {
        formant.prepare(sr);
        comb.prepare(sr, 50.f);
    }

    void reset() {
        env = GrainEnvelope();
        formant.reset();
        comb.reset();
        active = false;
    }
};

// ---- Single DUST voice ----
struct DustVoice {
    GrainEnvelope env;
    double readPos = 0.0;
    float panL = 0.707f, panR = 0.707f;
    float level = 0.25f;
    bool active = false;
};

// ---- Phantom Limb: 6 delay taps with progressive darkening ----
class PhantomLimb {
public:
    static constexpr int NUM_TAPS = 6;

    void prepare(float sampleRate) {
        sr = sampleRate;
        // Max delay: 2 seconds
        int maxSamples = static_cast<int>(sampleRate * 2.0f) + 1;
        delete[] delayL; delete[] delayR;
        delayL = new float[maxSamples]();
        delayR = new float[maxSamples]();
        delaySize = maxSamples;
        writePos = 0;

        for (int t = 0; t < NUM_TAPS; ++t) {
            lpFilters[t].reset();
            // Progressive LP darkening: 7000 -> 3000 Hz
            float cutoff = 7000.f - t * 800.f;
            lpFilters[t].setParams(Biquad::LowPass, cutoff, 0.707f, sampleRate);
        }
    }

    ~PhantomLimb() {
        delete[] delayL;
        delete[] delayR;
    }

    /// Feed DUST output into the delay network.
    void write(float left, float right) {
        if (!delayL) return;
        delayL[writePos] = left;
        delayR[writePos] = right;
        writePos = (writePos + 1) % delaySize;
    }

    /// Read all 6 taps, mix with random gating.
    /// Returns stereo sum of all active taps.
    void read(float& outL, float& outR, LFSR& rng,
              float swirlLFO, float gateProbability) {
        outL = outR = 0.f;

        for (int t = 0; t < NUM_TAPS; ++t) {
            // Random gate: probability decreases for longer taps
            float prob = gateProbability * (1.f - t * 0.12f);
            // Gate decision at ~100 Hz (not every sample)
            if (gateCounters[t]++ >= static_cast<int>(sr / 100.f)) {
                gateCounters[t] = 0;
                gateStates[t] = (rng.nextFloat() < prob);
            }

            if (!gateStates[t]) continue;

            // Read from delay
            float delaySec = delayTimes[t];
            int delaySamples = static_cast<int>(delaySec * sr);
            int readPos = writePos - delaySamples;
            if (readPos < 0) readPos += delaySize;

            float tapL = delayL[readPos];
            float tapR = delayR[readPos];

            // Progressive LP filter
            tapL = lpFilters[t].process(tapL);
            // Note: using same filter for both channels (mono LP is fine for darkening)
            tapR = lpFilters[t].process(tapR);

            // Per-tap pan (slow sinusoidal drift)
            float panAngle = (tapPanBase[t] + swirlLFO * 0.4f) * 3.14159265f * 0.5f;
            float pL = std::cos(panAngle * 0.5f + 0.785f);
            float pR = std::sin(panAngle * 0.5f + 0.785f);

            // Progressive level reduction
            float tapLevel = 1.f - t * 0.13f;

            outL += tapL * pL * tapLevel;
            outR += tapR * pR * tapLevel;
        }

        // Scale down
        outL *= 0.2f;
        outR *= 0.2f;
    }

    void reset() {
        if (delayL) std::memset(delayL, 0, sizeof(float) * delaySize);
        if (delayR) std::memset(delayR, 0, sizeof(float) * delaySize);
        writePos = 0;
        for (int t = 0; t < NUM_TAPS; ++t) {
            lpFilters[t].reset();
            gateStates[t] = false;
            gateCounters[t] = 0;
        }
    }

private:
    float sr = 48000.f;
    float* delayL = nullptr;
    float* delayR = nullptr;
    int delaySize = 0;
    int writePos = 0;

    Biquad lpFilters[NUM_TAPS];
    bool gateStates[NUM_TAPS] = {};
    int gateCounters[NUM_TAPS] = {};

    // Delay times in seconds (from blueprint)
    static constexpr float delayTimes[NUM_TAPS] = {
        0.060f, 0.220f, 0.380f, 0.550f, 0.850f, 1.700f
    };
    // Base pan positions (spread across stereo field)
    static constexpr float tapPanBase[NUM_TAPS] = {
        -0.7f, 0.5f, -0.3f, 0.8f, -0.6f, 0.2f
    };
};


// ======== MAIN GRAIN LAYER CLASS ========

class GrainLayer {
public:
    static constexpr int MASS_VOICES = 4;
    static constexpr int DUST_VOICES = 4;

    void prepare(float sampleRate) {
        sr = sampleRate;
        for (int i = 0; i < MASS_VOICES; ++i)
            mass[i].prepare(sampleRate);
        phantom.prepare(sampleRate);
        dustHP.reset();
        dustHP.setParams(Biquad::HighPass, 3000.f, 0.707f, sampleRate);
        rng.seed(0xDEAD);
    }

    /// Process one stereo sample, reading grains from the buffer.
    /// Adds MASS + DUST output to outL/outR.
    void process(const CircularBuffer& buf,
                 float& outL, float& outR,
                 // LFO values
                 float glacierUni, float tideUni,
                 float swirlBi, float shimmerUni,
                 // Params
                 float blend,      // 0 = more DUST, 1 = more MASS
                 float tension,    // comb filter stress
                 float evolve,     // stage evolution (formant wet/dry)
                 float inputAmp    // input amplitude for density reactivity
    ) {
        double dt = 1.0 / sr;

        // ========================================
        // MASS: long smeared bowing grains
        // ========================================
        float massL = 0.f, massR = 0.f;
        float massGain = 0.25f + blend * 0.25f; // louder when blend is high

        // Trigger logic: slow interval modulated by glacier LFO
        massTimer += dt;
        float massInterval = 0.7f + glacierUni * 0.8f; // 0.7-1.5s
        if (massTimer >= massInterval) {
            massTimer = 0.0;
            triggerMassGrain(buf);
        }

        // Process active MASS voices
        for (int v = 0; v < MASS_VOICES; ++v) {
            auto& voice = mass[v];
            if (!voice.active) continue;

            float envVal = voice.env.next();
            if (voice.env.isDone()) {
                voice.active = false;
                continue;
            }

            // Read from buffer with glissando
            voice.readRate = std::pow(2.0, voice.glissRate / 1200.0);
            voice.readPos += voice.reverse ? -voice.readRate : voice.readRate;

            // Wrap
            if (voice.readPos < 0) voice.readPos += buf.getSize();
            if (voice.readPos >= buf.getSize()) voice.readPos -= buf.getSize();

            float sL, sR;
            // Stereo decorrelation: L and R from offset positions
            float tmpR2, tmpL2;
            buf.readCubic(voice.readPos, sL, tmpR2);
            buf.readCubic(voice.readPos + 53.0 + v * 31.0, tmpL2, sR);

            // Formant filter
            float formantMod = shimmerUni;
            float formantWet = 0.3f + evolve * 0.4f; // more wet as it evolves
            voice.formant.process(sL, sR, formantMod, tension, formantWet);

            // Comb filter (string tension)
            float combDelay = 18.f + shimmerUni * 16.f; // 18-34ms
            float combFb = tension * 0.7f;
            float combWet = tension * 0.5f;
            voice.comb.process(sL, sR, combDelay, combFb, combWet);

            // Apply envelope and level
            sL *= envVal * voice.level;
            sR *= envVal * voice.level;

            // Pan
            massL += sL * voice.panL;
            massR += sR * voice.panR;
        }

        outL += massL * massGain;
        outR += massR * massGain;

        // ========================================
        // DUST: short stippled friction grains
        // ========================================
        float dustL = 0.f, dustR = 0.f;
        float dustGain = 0.35f - blend * 0.2f; // louder when blend is low

        // Stochastic trigger: density modulated by input amp + LFO
        dustTimer += dt;
        float dustDensity = 5.f + inputAmp * 15.f + tideUni * 5.f; // 5-25 Hz
        float dustInterval = 1.f / std::max(dustDensity, 1.f);
        // Add randomness (Dust.kr equivalent)
        float dustProb = static_cast<float>(dt) * dustDensity;
        if (rng.nextFloat() < dustProb) {
            triggerDustGrain(buf);
        }

        // Process active DUST voices
        for (int v = 0; v < DUST_VOICES; ++v) {
            auto& voice = dust[v];
            if (!voice.active) continue;

            float envVal = voice.env.next();
            if (voice.env.isDone()) {
                voice.active = false;
                continue;
            }

            float sL, sR;
            // Stereo decorrelation: read L and R from offset positions
            float tmpR2, tmpL2;
            buf.readLinear(voice.readPos, sL, tmpR2);
            buf.readLinear(voice.readPos + 73.0, tmpL2, sR); // ~1.5ms offset
            voice.readPos += 1.0; // always rate = 1.0

            // HP filter for sul ponticello brightness
            sL = dustHP.process(sL);
            // (reusing same filter state for L channel — mono HP is fine for character)

            sL *= envVal * voice.level;
            sR *= envVal * voice.level;

            dustL += sL * voice.panL;
            dustR += sR * voice.panR;
        }

        // Feed dust output into Phantom Limb before adding to output
        phantom.write(dustL, dustR);

        // Read phantom limb dispersed taps
        float phantomL = 0.f, phantomR = 0.f;
        float phantomGate = 0.4f + inputAmp * 0.3f; // more gates when louder
        phantom.read(phantomL, phantomR, rng, swirlBi, phantomGate);

        outL += (dustL + phantomL) * dustGain;
        outR += (dustR + phantomR) * dustGain;
    }

    void reset() {
        for (int i = 0; i < MASS_VOICES; ++i) mass[i].reset();
        for (int i = 0; i < DUST_VOICES; ++i) {
            dust[i] = DustVoice();
            dust[i].active = false;
        }
        phantom.reset();
        dustHP.reset();
        massTimer = 0.0;
        dustTimer = 0.0;
    }

private:
    float sr = 48000.f;
    MassVoice mass[MASS_VOICES];
    DustVoice dust[DUST_VOICES];
    PhantomLimb phantom;
    Biquad dustHP;
    LFSR rng;

    double massTimer = 0.0;
    double dustTimer = 0.0;

    // ---- Trigger a new MASS grain ----
    void triggerMassGrain(const CircularBuffer& buf) {
        // Find free or oldest voice
        int target = 0;
        for (int v = 0; v < MASS_VOICES; ++v) {
            if (!mass[v].active) { target = v; break; }
        }
        // If all active, steal the one closest to finishing
        if (mass[target].active) {
            for (int v = 1; v < MASS_VOICES; ++v) {
                if (mass[v].env.getValue() < mass[target].env.getValue())
                    target = v;
            }
            mass[target].env.startRelease(); // fade out stolen voice
        }

        auto& voice = mass[target];
        voice.active = true;

        // Grain length: 3-6 seconds
        voice.grainLengthSec = rng.nextRange(3.0f, 6.0f);
        float grainMs = voice.grainLengthSec * 1000.f;

        // Slow envelope: 150-400ms attack, 250-500ms release
        float attackMs  = rng.nextRange(150.f, 400.f);
        float releaseMs = rng.nextRange(250.f, 500.f);
        voice.env.trigger(attackMs, releaseMs, 1.0f, sr);
        // Auto-release after grain duration
        float sustainMs = grainMs - attackMs - releaseMs;
        // We'll rely on the grain running out of buffer or the trigger cycle

        // Read position: 2-20% behind write head
        float behindFrac = rng.nextRange(0.02f, 0.20f);
        float behindSec = behindFrac * (buf.getSize() / static_cast<float>(sr));
        voice.readPos = buf.secondsToPos(behindSec);

        // Glissando: subtle pitch slide (+/-1.5 cents/second)
        voice.glissRate = rng.nextRange(-1.5f, 1.5f);

        // Occasional reverse (12% chance)
        voice.reverse = rng.nextFloat() < 0.12f;

        // Level with variation
        voice.level = rng.nextRange(0.3f, 0.5f);

        // Golden ratio-ish pan
        float pan = rng.nextRange(-0.8f, 0.8f);
        float panAngle = (pan + 1.f) * 0.25f * 3.14159265f;
        voice.panL = std::cos(panAngle);
        voice.panR = std::sin(panAngle);
    }

    // ---- Trigger a new DUST grain ----
    void triggerDustGrain(const CircularBuffer& buf) {
        // Find free voice
        int target = -1;
        for (int v = 0; v < DUST_VOICES; ++v) {
            if (!dust[v].active) { target = v; break; }
        }
        if (target < 0) {
            // All busy — steal oldest
            target = 0;
            for (int v = 1; v < DUST_VOICES; ++v) {
                if (dust[v].env.getValue() < dust[target].env.getValue())
                    target = v;
            }
        }

        auto& voice = dust[target];
        voice.active = true;

        // Short grain: 30-120ms
        float grainMs = rng.nextRange(30.f, 120.f);
        voice.env.triggerAuto(grainMs, sr);

        // Read position: close to write head (2-10% behind)
        float behindFrac = rng.nextRange(0.02f, 0.10f);
        float behindSec = behindFrac * (buf.getSize() / static_cast<float>(sr));
        voice.readPos = buf.secondsToPos(behindSec);

        // Level
        voice.level = rng.nextRange(0.15f, 0.35f);

        // Random stereo scatter
        float pan = rng.nextRange(-1.f, 1.f);
        float panAngle = (pan + 1.f) * 0.25f * 3.14159265f;
        voice.panL = std::cos(panAngle);
        voice.panR = std::sin(panAngle);
    }
};
