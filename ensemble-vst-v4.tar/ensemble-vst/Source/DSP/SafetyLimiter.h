// SafetyLimiter.h
// ENSEMBLE VST — Output safety: tanh soft clip + DC blocker
// Essential when running high feedback (pre-level 0.93+).

#pragma once
#include <cmath>

class SafetyLimiter {
public:
    /// Process one stereo sample in-place.
    void process(float& left, float& right) {
        // DC blocker (1st-order HP, ~5 Hz at 48kHz)
        // y[n] = x[n] - x[n-1] + R * y[n-1], R ~= 0.9995
        float dcOutL = left - dcInL + dcR * dcOutPrevL;
        dcInL = left;
        dcOutPrevL = dcOutL;

        float dcOutR = right - dcInR + dcR * dcOutPrevR;
        dcInR = right;
        dcOutPrevR = dcOutR;

        // Soft clip (tanh approximation — fast, smooth)
        left  = fastTanh(dcOutL * drive) * postGain;
        right = fastTanh(dcOutR * drive) * postGain;
    }

    /// Process a stereo block in-place.
    void processBlock(float* left, float* right, int numSamples) {
        for (int i = 0; i < numSamples; ++i)
            process(left[i], right[i]);
    }

    void reset() {
        dcInL = dcInR = 0.f;
        dcOutPrevL = dcOutPrevR = 0.f;
    }

    void setSampleRate(double sr) {
        // DC blocker coefficient: R = 1 - (2*pi*fc / sr)
        // fc = 5 Hz
        dcR = 1.f - static_cast<float>(6.283185307 * 5.0 / sr);
    }

    // Drive: how hard we push into the tanh. 1.0 = gentle, 2.0 = warm.
    float drive = 1.0f;
    // Post gain to compensate for tanh compression.
    float postGain = 0.95f;

private:
    float dcR = 0.9993f;
    float dcInL = 0.f, dcInR = 0.f;
    float dcOutPrevL = 0.f, dcOutPrevR = 0.f;

    /// Fast tanh approximation (Pade, accurate to ~0.001 for |x| < 3).
    static float fastTanh(float x) {
        if (x < -3.f) return -1.f;
        if (x >  3.f) return  1.f;
        float x2 = x * x;
        return x * (27.f + x2) / (27.f + 9.f * x2);
    }
};
