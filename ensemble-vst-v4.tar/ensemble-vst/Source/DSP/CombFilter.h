// CombFilter.h
// ENSEMBLE VST — Comb filter for string tension resonance
// Short delay (12-34ms) with feedback creates wire-like metallic quality.
// Tension parameter controls feedback: low = warm, high = stressed/ringing.

#pragma once
#include <cmath>
#include <cstring>
#include <algorithm>

class CombFilter {
public:
    void prepare(float sampleRate, float maxDelayMs = 50.f) {
        sr = sampleRate;
        maxDelaySamples = static_cast<int>(maxDelayMs * 0.001f * sampleRate) + 1;
        if (bufferL) delete[] bufferL;
        if (bufferR) delete[] bufferR;
        bufferL = new float[maxDelaySamples]();
        bufferR = new float[maxDelaySamples]();
        writePos = 0;
    }

    ~CombFilter() {
        delete[] bufferL;
        delete[] bufferR;
    }

    /// Process stereo sample in-place.
    /// delayMs: comb delay time (12-34ms for string tension character)
    /// feedback: 0-0.95 (tension parameter maps here)
    /// wetDry: 0-1 blend
    void process(float& left, float& right,
                 float delayMs, float feedback, float wetDry) {
        float delaySamples = delayMs * 0.001f * sr;
        delaySamples = std::max(1.f, std::min(delaySamples, static_cast<float>(maxDelaySamples - 1)));

        // Read with linear interpolation
        int readPos = writePos - static_cast<int>(delaySamples);
        if (readPos < 0) readPos += maxDelaySamples;
        int readPos2 = (readPos + 1) % maxDelaySamples;
        float frac = delaySamples - static_cast<int>(delaySamples);

        float delayedL = bufferL[readPos] + frac * (bufferL[readPos2] - bufferL[readPos]);
        float delayedR = bufferR[readPos] + frac * (bufferR[readPos2] - bufferR[readPos]);

        // One-pole LP in feedback path (darkens successive repeats)
        dampL += 0.4f * (delayedL - dampL);
        dampR += 0.4f * (delayedR - dampR);

        // Write: input + damped feedback
        feedback = std::min(feedback, 0.95f); // safety clamp
        bufferL[writePos] = left  + dampL * feedback;
        bufferR[writePos] = right + dampR * feedback;

        writePos = (writePos + 1) % maxDelaySamples;

        // Output: wet/dry mix
        left  = left  * (1.f - wetDry) + delayedL * wetDry;
        right = right * (1.f - wetDry) + delayedR * wetDry;
    }

    void reset() {
        if (bufferL) std::memset(bufferL, 0, sizeof(float) * maxDelaySamples);
        if (bufferR) std::memset(bufferR, 0, sizeof(float) * maxDelaySamples);
        dampL = dampR = 0.f;
        writePos = 0;
    }

private:
    float sr = 48000.f;
    float* bufferL = nullptr;
    float* bufferR = nullptr;
    int maxDelaySamples = 0;
    int writePos = 0;
    float dampL = 0.f, dampR = 0.f;
};
