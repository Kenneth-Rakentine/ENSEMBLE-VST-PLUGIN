// WeaveEngine.h
// ENSEMBLE VST — Layer 0: Continuous spectral interference engine
// Manages 8 overlapping readers with golden ratio panning,
// incommensurate LFO modulation, and input-reactive density.

#pragma once
#include "CircularBuffer.h"
#include "ContinuousReader.h"
#include "LFOSystem.h"
#include <cmath>
#include <algorithm>

class WeaveEngine {
public:
    static constexpr int NUM_VOICES = 8;
    static constexpr double PHI = 1.618033988749895;

    void prepare(double sampleRate, double bufferSeconds = 60.0) {
        sr = sampleRate;
        buffer.allocate(sampleRate, bufferSeconds);
        lfo.reset();

        // Configure 8 voices with golden ratio pan distribution
        // and staggered offsets behind the write head.
        // Offsets: spread from 1.2s to 10s behind write head.
        // Closer voices = brighter, more present.
        // Farther voices = darker, more diffuse.
        struct VoiceCfg {
            double offsetSec;
            float driftScale;
        };
        static constexpr VoiceCfg cfg[NUM_VOICES] = {
            { 1.2,  0.30f },  // Voice 0: close reader, low drift
            { 2.0,  0.45f },  // Voice 1: near reader
            { 3.3,  0.55f },  // Voice 2: mid reader
            { 4.5,  0.50f },  // Voice 3: mid reader
            { 6.0,  0.60f },  // Voice 4: mid-far reader
            { 7.5,  0.65f },  // Voice 5: far reader
            { 8.8,  0.70f },  // Voice 6: far reader
            { 10.0, 0.40f },  // Voice 7: furthest, lower drift
        };

        for (int i = 0; i < NUM_VOICES; ++i) {
            // Golden ratio panning: pan = ((i * phi) mod 1) * 2 - 1
            float panBase = static_cast<float>(
                std::fmod(i * PHI, 1.0) * 2.0 - 1.0
            );
            voices[i].init(cfg[i].offsetSec, cfg[i].driftScale, panBase, i);
            voices[i].reset();
        }

        // Reset envelope follower
        inputEnvelope = 0.f;
    }

    /// Process a block of audio. In-place: inputL/R are read, outputL/R are written.
    void processBlock(const float* inputL, const float* inputR,
                      float* outputL, float* outputR,
                      int numSamples,
                      // User parameters (0-1 range)
                      float blend,      // 0 = DUST-biased, 1 = MASS-biased
                      float tension,    // comb filter stress (future use)
                      float textureAmt, // overall weave level
                      float evolve,     // autonomous modulation depth
                      float preLevel,   // buffer persistence (0.85-0.99)
                      float inputGain,  // input level to buffer
                      float dryLevel    // pass-through dry signal level
    ) {
        double dt = 1.0 / sr; // per-sample time increment

        for (int s = 0; s < numSamples; ++s) {
            // --- Input envelope follower (smooth RMS-ish) ---
            float inMag = std::abs(inputL[s]) + std::abs(inputR[s]);
            float envAttack = 0.001f;  // ~1ms attack
            float envRelease = 0.9997f; // ~200ms release at 48kHz
            if (inMag > inputEnvelope)
                inputEnvelope += envAttack * (inMag - inputEnvelope);
            else
                inputEnvelope *= envRelease;

            // --- Write input to buffer ---
            buffer.write(
                inputL[s] * inputGain,
                inputR[s] * inputGain,
                preLevel
            );

            // --- Advance LFOs ---
            lfo.update(dt);

            // --- Pre-compute LFO values (scaled by evolve) ---
            float glacierU = 0.5f + (lfo.uni(LFOSystem::Glacier) - 0.5f) * evolve;
            float tideU    = 0.5f + (lfo.uni(LFOSystem::Tide)    - 0.5f) * evolve;
            float driftB   = lfo.bi(LFOSystem::Drift)   * evolve;
            float swirlB   = lfo.bi(LFOSystem::Swirl)   * evolve;
            float shimmerU = 0.5f + (lfo.uni(LFOSystem::Shimmer) - 0.5f) * evolve;
            float rippleB  = lfo.bi(LFOSystem::Ripple)  * evolve;

            // --- Sum all 8 weave voices ---
            float weaveL = 0.f, weaveR = 0.f;

            for (int v = 0; v < NUM_VOICES; ++v) {
                // Each voice gets a unique phase offset on LFOs
                // by using slightly shifted LFO reads
                float vPhase = static_cast<float>(v) / NUM_VOICES;
                float gU = 0.5f + (glacierU - 0.5f) * (0.8f + vPhase * 0.4f);
                float tU = 0.5f + (tideU    - 0.5f) * (0.7f + vPhase * 0.6f);
                // Drift and swirl get per-voice decorrelation
                float dB = driftB  * (0.6f + vPhase * 0.8f);
                float swB = swirlB * (0.7f + vPhase * 0.8f);
                float shU = 0.5f + (shimmerU - 0.5f) * (0.8f + vPhase * 0.4f);
                float rB  = rippleB * (0.7f + vPhase * 0.6f);

                voices[v].process(
                    buffer, weaveL, weaveR,
                    gU, tU, dB, swB, shU, rB,
                    blend, textureAmt,
                    std::min(inputEnvelope, 1.0f)
                );
            }

            // Scale down: 8 voices summed, prevent clipping
            constexpr float voiceScale = 1.0f / NUM_VOICES;
            weaveL *= voiceScale;
            weaveR *= voiceScale;

            // --- Store weave output for downstream processing ---
            lastWeaveL = weaveL;
            lastWeaveR = weaveR;

            // --- Output: dry + weave ---
            outputL[s] = inputL[s] * dryLevel + weaveL;
            outputR[s] = inputR[s] * dryLevel + weaveR;
        }
    }

    /// Get the last computed weave output (for cross-mod matrix).
    void getLastWeave(float& l, float& r) const {
        l = lastWeaveL;
        r = lastWeaveR;
    }

    /// Get current input envelope (for UI metering / reactivity).
    float getInputEnvelope() const { return inputEnvelope; }

    /// Clear buffer and reset all voices.
    void clear() {
        buffer.clear();
        for (int i = 0; i < NUM_VOICES; ++i)
            voices[i].reset();
        inputEnvelope = 0.f;
        lastWeaveL = lastWeaveR = 0.f;
    }

    /// Access the circular buffer (for MASS/DUST grain layers).
    const CircularBuffer& getBuffer() const { return buffer; }
    CircularBuffer& getBuffer() { return buffer; }

    /// Access LFO system (for UI visualization / downstream modulation).
    const LFOSystem& getLFOs() const { return lfo; }

private:
    double sr = 48000.0;
    CircularBuffer buffer;
    ContinuousReader voices[NUM_VOICES];
    LFOSystem lfo;

    float inputEnvelope = 0.f;
    float lastWeaveL = 0.f;
    float lastWeaveR = 0.f;
};
