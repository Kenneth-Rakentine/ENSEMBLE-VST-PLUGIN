// PluginProcessor.h — ENSEMBLE VST
#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_audio_utils/juce_audio_utils.h>
#include "DSP/EnsembleProcessor.h"

class EnsembleAudioProcessor : public juce::AudioProcessor {
public:
    EnsembleAudioProcessor();
    ~EnsembleAudioProcessor() override;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 10.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;

    EnsembleProcessor& getDSP() { return dsp; }
    juce::AudioProcessorValueTreeState& getAPVTS() { return apvts; }

    // Clear buffer (called from UI thread, thread-safe flag)
    void requestClear() { clearRequested.store(true); }

    // --- Parameter IDs ---
    static constexpr const char* ID_BLEND    = "blend";
    static constexpr const char* ID_TENSION  = "tension";
    static constexpr const char* ID_TEXTURE  = "texture";
    static constexpr const char* ID_EVOLVE   = "evolve";
    static constexpr const char* ID_PERSIST  = "persist";
    static constexpr const char* ID_INPUT    = "input";
    static constexpr const char* ID_DRY      = "dry";
    static constexpr const char* ID_OUTPUT   = "output";
    // EQ bands
    static constexpr const char* ID_EQ_WET   = "eqWet";
    static constexpr const char* ID_EQ[12]   = {
        "eq60","eq120","eq250","eq500","eq1k","eq2k",
        "eq3k","eq4k","eq6k","eq8k","eq12k","eq16k"
    };
    // Bandpass filter
    static constexpr const char* ID_BP_FREQ    = "bpFreq";
    static constexpr const char* ID_BP_ENABLED = "bpEnabled";

private:
    EnsembleProcessor dsp;
    juce::AudioProcessorValueTreeState apvts;
    std::atomic<bool> clearRequested { false };

    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(EnsembleAudioProcessor)
};
