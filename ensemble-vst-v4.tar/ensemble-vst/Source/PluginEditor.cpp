// PluginEditor.cpp — ENSEMBLE VST — Soviet CRT Interface v2
// 3D skeuomorphic knobs, compact layout, bandpass filter toggle
#include "PluginEditor.h"
#include <cmath>

namespace Colors {
    const juce::Colour enclosure    (0xFF1C1C1E);
    const juce::Colour screwDark    (0xFF111113);
    const juce::Colour screwLight   (0xFF3A3A3D);
    const juce::Colour crtBg        (0xFF0A0808);
    const juce::Colour crtBezel     (0xFF151517);
    const juce::Colour phosphorDim  (0xFF3A0808);
    const juce::Colour phosphorMed  (0xFFAA2222);
    const juce::Colour phosphorBrt  (0xFFEE3333);
    const juce::Colour phosphorHot  (0xFFFF6644);
    const juce::Colour knobBody     (0xFF2A2A2E);
    const juce::Colour knobDark     (0xFF1A1A1E);
    const juce::Colour knobLight    (0xFF444448);
    const juce::Colour knobRim      (0xFF555558);
    const juce::Colour knobPointer  (0xFFDDDDDD);
    const juce::Colour textDim      (0xFF666668);
    const juce::Colour textBrt      (0xFF999999);
    const juce::Colour labelText    (0xFF888888);
    const juce::Colour clearBtnBg   (0xFF2A1111);
    const juce::Colour clearBtnText (0xFFCC3333);
    const juce::Colour toggleOn     (0xFFCC3333);
    const juce::Colour toggleOff    (0xFF333336);
}

// ---- 3D Skeuomorphic LookAndFeel ----
class SovietLookAndFeel : public juce::LookAndFeel_V4 {
public:
    SovietLookAndFeel() {
        setColour(juce::Slider::textBoxTextColourId, Colors::textBrt);
        setColour(juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
        setColour(juce::Slider::textBoxBackgroundColourId, juce::Colours::transparentBlack);
        setColour(juce::ToggleButton::tickColourId, Colors::toggleOn);
    }

    void drawRotarySlider(juce::Graphics& g, int x, int y, int w, int h,
                          float sliderPos, float startAngle, float endAngle,
                          juce::Slider&) override
    {
        float cx = x + w * 0.5f, cy = y + h * 0.5f;
        float r = std::min(w, h) * 0.40f;

        // Shadow behind knob
        g.setColour(juce::Colour(0x40000000));
        g.fillEllipse(cx - r + 1, cy - r + 2, r * 2, r * 2);

        // Recessed well
        g.setColour(Colors::screwDark);
        g.fillEllipse(cx - r - 2, cy - r - 2, (r + 2) * 2, (r + 2) * 2);

        // Knob body — radial gradient for 3D dome effect
        {
            juce::ColourGradient grad(
                Colors::knobLight, cx - r * 0.3f, cy - r * 0.3f,
                Colors::knobDark, cx + r * 0.5f, cy + r * 0.7f, true);
            g.setGradientFill(grad);
            g.fillEllipse(cx - r, cy - r, r * 2, r * 2);
        }

        // Rim highlight (top-left light source)
        {
            juce::ColourGradient rimGrad(
                Colors::knobRim.withAlpha(0.6f), cx - r, cy - r,
                juce::Colours::transparentBlack, cx + r, cy + r, true);
            g.setGradientFill(rimGrad);
            g.drawEllipse(cx - r, cy - r, r * 2, r * 2, 1.5f);
        }

        // Knurled edge texture (subtle radial lines)
        g.setColour(juce::Colour(0x12FFFFFF));
        for (int i = 0; i < 36; ++i) {
            float a = (float)i * 6.2832f / 36.f;
            float x0 = cx + (r - 2) * std::cos(a);
            float y0 = cy + (r - 2) * std::sin(a);
            float x1 = cx + r * std::cos(a);
            float y1 = cy + r * std::sin(a);
            g.drawLine(x0, y0, x1, y1, 0.5f);
        }

        // Arc track behind pointer (faint)
        {
            juce::Path arc;
            float trackR = r + 5;
            arc.addCentredArc(cx, cy, trackR, trackR, 0,
                              startAngle - 1.5708f, endAngle - 1.5708f, true);
            g.setColour(juce::Colour(0xFF222225));
            g.strokePath(arc, juce::PathStrokeType(2.f));
        }

        // Active arc (red phosphor glow)
        {
            juce::Path arc;
            float trackR = r + 5;
            float curAngle = startAngle + sliderPos * (endAngle - startAngle);
            arc.addCentredArc(cx, cy, trackR, trackR, 0,
                              startAngle - 1.5708f, curAngle - 1.5708f, true);
            g.setColour(Colors::phosphorMed.withAlpha(0.7f));
            g.strokePath(arc, juce::PathStrokeType(2.f));
        }

        // Pointer notch — indented line
        float angle = startAngle + sliderPos * (endAngle - startAngle);
        float cosA = std::cos(angle - 1.5708f);
        float sinA = std::sin(angle - 1.5708f);

        // Dark line (indent shadow)
        float innerR = r * 0.3f, outerR = r * 0.82f;
        g.setColour(juce::Colour(0xFF0A0A0C));
        g.drawLine(cx + innerR * cosA, cy + innerR * sinA,
                   cx + outerR * cosA, cy + outerR * sinA, 2.5f);
        // Bright edge (indent highlight)
        g.setColour(Colors::knobPointer);
        g.drawLine(cx + innerR * cosA + 0.5f, cy + innerR * sinA + 0.5f,
                   cx + outerR * cosA + 0.5f, cy + outerR * sinA + 0.5f, 1.0f);

        // Center cap — raised dome
        float capR = r * 0.22f;
        {
            juce::ColourGradient capGrad(
                Colors::knobLight, cx - capR * 0.4f, cy - capR * 0.4f,
                Colors::knobDark, cx + capR * 0.4f, cy + capR * 0.4f, true);
            g.setGradientFill(capGrad);
            g.fillEllipse(cx - capR, cy - capR, capR * 2, capR * 2);
        }
    }

    void drawLinearSlider(juce::Graphics& g, int x, int y, int w, int h,
                          float sliderPos, float, float,
                          juce::Slider::SliderStyle style, juce::Slider&) override
    {
        if (style == juce::Slider::LinearVertical) {
            float trackX = x + w * 0.5f;
            float trackTop = (float)y + 2;
            float trackBot = (float)(y + h) - 2;

            // Track groove (recessed)
            g.setColour(Colors::screwDark);
            g.fillRoundedRectangle(trackX - 2, trackTop, 4, trackBot - trackTop, 2);
            g.setColour(juce::Colour(0x18FFFFFF));
            g.drawLine(trackX + 2, trackTop, trackX + 2, trackBot, 0.5f);

            // Fill from center (bipolar EQ)
            float center = (trackTop + trackBot) * 0.5f;
            float thumbY = sliderPos;
            g.setColour(Colors::phosphorMed.withAlpha(0.6f));
            if (thumbY < center)
                g.fillRoundedRectangle(trackX - 1.5f, thumbY, 3, center - thumbY, 1);
            else
                g.fillRoundedRectangle(trackX - 1.5f, center, 3, thumbY - center, 1);

            // Thumb — 3D fader cap
            float tw = 14, th = 8;
            float tx = trackX - tw * 0.5f, ty = thumbY - th * 0.5f;
            {
                juce::ColourGradient grad(
                    Colors::knobLight, tx, ty,
                    Colors::knobDark, tx, ty + th, false);
                g.setGradientFill(grad);
                g.fillRoundedRectangle(tx, ty, tw, th, 2.5f);
            }
            // Fader cap groove
            g.setColour(juce::Colour(0x30000000));
            g.drawLine(tx + 3, thumbY, tx + tw - 3, thumbY, 0.8f);
            // Edge
            g.setColour(Colors::knobRim.withAlpha(0.4f));
            g.drawRoundedRectangle(tx, ty, tw, th, 2.5f, 0.7f);
        }
    }

    void drawToggleButton(juce::Graphics& g, juce::ToggleButton& btn,
                          bool shouldDrawButtonAsHighlighted, bool shouldDrawButtonAsDown) override
    {
        (void)shouldDrawButtonAsHighlighted; (void)shouldDrawButtonAsDown;
        auto bounds = btn.getLocalBounds().toFloat().reduced(2);
        float w = bounds.getWidth(), h = bounds.getHeight();

        // Pill-shaped toggle
        float pillW = std::min(w, 32.f), pillH = std::min(h, 16.f);
        float px = bounds.getCentreX() - pillW * 0.5f;
        float py = bounds.getCentreY() - pillH * 0.5f;

        bool on = btn.getToggleState();

        // Track
        g.setColour(on ? Colors::toggleOn.withAlpha(0.3f) : Colors::toggleOff);
        g.fillRoundedRectangle(px, py, pillW, pillH, pillH * 0.5f);
        g.setColour(juce::Colour(0x20FFFFFF));
        g.drawRoundedRectangle(px, py, pillW, pillH, pillH * 0.5f, 0.7f);

        // Thumb circle
        float circR = pillH * 0.4f;
        float circX = on ? (px + pillW - pillH * 0.5f) : (px + pillH * 0.5f);
        float circY = py + pillH * 0.5f;

        juce::ColourGradient cg(Colors::knobLight, circX - circR * 0.3f, circY - circR * 0.3f,
                                Colors::knobDark, circX + circR * 0.3f, circY + circR * 0.3f, true);
        g.setGradientFill(cg);
        g.fillEllipse(circX - circR, circY - circR, circR * 2, circR * 2);

        if (on) {
            g.setColour(Colors::toggleOn.withAlpha(0.4f));
            g.drawEllipse(circX - circR, circY - circR, circR * 2, circR * 2, 1.f);
        }
    }

    void drawButtonBackground(juce::Graphics& g, juce::Button& btn, const juce::Colour& bg,
                              bool over, bool down) override
    {
        auto bounds = btn.getLocalBounds().toFloat().reduced(1);
        auto col = down ? bg.brighter(0.1f) : (over ? bg.brighter(0.05f) : bg);
        g.setColour(col);
        g.fillRoundedRectangle(bounds, 4.f);
        g.setColour(juce::Colour(0x20FFFFFF));
        g.drawRoundedRectangle(bounds, 4.f, 0.7f);
    }
};

// ---- Constructor ----

EnsembleAudioProcessorEditor::EnsembleAudioProcessorEditor(EnsembleAudioProcessor& p)
    : AudioProcessorEditor(&p), processor(p)
{
    static SovietLookAndFeel sovietLF;
    setLookAndFeel(&sovietLF);

    // Weave Engine knobs
    setupRotary(blendK,   blendL,   "BLEND",   blendA,   EnsembleAudioProcessor::ID_BLEND);
    setupRotary(tensionK, tensionL, "TENSION", tensionA, EnsembleAudioProcessor::ID_TENSION);
    setupRotary(textureK, textureL, "TEXTURE", textureA, EnsembleAudioProcessor::ID_TEXTURE);
    setupRotary(evolveK,  evolveL,  "EVOLVE",  evolveA,  EnsembleAudioProcessor::ID_EVOLVE);

    // Mix knobs
    setupRotary(persistK, persistL, "PERSIST", persistA, EnsembleAudioProcessor::ID_PERSIST);
    setupRotary(inputK,   inputL,   "INPUT",   inputA,   EnsembleAudioProcessor::ID_INPUT);
    setupRotary(dryK,     dryL,     "DRY",     dryA,     EnsembleAudioProcessor::ID_DRY);
    setupRotary(outputK,  outputL,  "OUTPUT",  outputA,  EnsembleAudioProcessor::ID_OUTPUT);

    // EQ sliders
    const char* eqNames[12] = {"60","120","250","500","1k","2k","3k","4k","6k","8k","12k","16k"};
    for (int b = 0; b < 12; ++b)
        setupVertical(eqSliders[b], eqLabels[b], eqNames[b], eqA[b], EnsembleAudioProcessor::ID_EQ[b]);

    // EQ Wet
    setupRotary(eqWetK, eqWetL, "EQ MIX", eqWetA, EnsembleAudioProcessor::ID_EQ_WET);

    // Bandpass filter — toggle + freq knob
    bpToggle.setButtonText("BP");
    addAndMakeVisible(bpToggle);
    bpToggleA = std::make_unique<BA>(processor.getAPVTS(), EnsembleAudioProcessor::ID_BP_ENABLED, bpToggle);

    setupRotary(bpFreqK, bpFreqL, "BP FREQ", bpFreqA, EnsembleAudioProcessor::ID_BP_FREQ);

    // Clear button
    clearBtn.setButtonText("CLEAR");
    clearBtn.setColour(juce::TextButton::buttonColourId, Colors::clearBtnBg);
    clearBtn.setColour(juce::TextButton::textColourOffId, Colors::clearBtnText);
    clearBtn.onClick = [this]() { processor.requestClear(); };
    addAndMakeVisible(clearBtn);

    setSize(820, 460);  // Compact — no dead space
    startTimerHz(30);
}

EnsembleAudioProcessorEditor::~EnsembleAudioProcessorEditor() { setLookAndFeel(nullptr); }

void EnsembleAudioProcessorEditor::setupRotary(
    juce::Slider& k, juce::Label& l, const juce::String& text,
    std::unique_ptr<SA>& att, const juce::String& pid)
{
    k.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    k.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 52, 14);
    addAndMakeVisible(k);
    l.setText(text, juce::dontSendNotification);
    l.setJustificationType(juce::Justification::centred);
    l.setFont(juce::FontOptions(9.5f));
    l.setColour(juce::Label::textColourId, Colors::labelText);
    addAndMakeVisible(l);
    att = std::make_unique<SA>(processor.getAPVTS(), pid, k);
}

void EnsembleAudioProcessorEditor::setupVertical(
    juce::Slider& k, juce::Label& l, const juce::String& text,
    std::unique_ptr<SA>& att, const juce::String& pid)
{
    k.setSliderStyle(juce::Slider::LinearVertical);
    k.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    addAndMakeVisible(k);
    l.setText(text, juce::dontSendNotification);
    l.setJustificationType(juce::Justification::centred);
    l.setFont(juce::FontOptions(8.f));
    l.setColour(juce::Label::textColourId, Colors::textDim);
    addAndMakeVisible(l);
    att = std::make_unique<SA>(processor.getAPVTS(), pid, k);
}

// ---- Particle system ----

float EnsembleAudioProcessorEditor::fastRng() {
    rngState = rngState * 1664525u + 1013904223u;
    return (float)(rngState >> 8) / 16777216.f; // 0 to 1
}

void EnsembleAudioProcessorEditor::spawnParticle(float energy, float blend) {
    auto& p = particles[nextParticle];
    nextParticle = (nextParticle + 1) % MAX_PARTICLES;

    // Spawn near center with slight randomness
    p.x = 0.3f + fastRng() * 0.4f;
    p.y = 0.3f + fastRng() * 0.4f;

    // Velocity — drift outward from center with some swirl
    float angle = fastRng() * 6.2832f;
    float speed = 0.005f + energy * 0.02f;
    p.vx = std::cos(angle) * speed + (fastRng() - 0.5f) * 0.008f;
    p.vy = std::sin(angle) * speed + (fastRng() - 0.5f) * 0.008f;

    // Bigger particles for MASS (high blend), smaller for DUST (low blend)
    p.size = 1.0f + blend * 3.0f + fastRng() * 2.0f;
    p.life = 1.0f;
    p.decay = 0.008f + fastRng() * 0.015f; // variable fade rates
    p.brightness = 0.5f + energy * 0.5f;
}

void EnsembleAudioProcessorEditor::updateParticles(float dt) {
    for (int i = 0; i < MAX_PARTICLES; ++i) {
        auto& p = particles[i];
        if (p.life <= 0.f) continue;

        // Move
        p.x += p.vx * dt * 30.f;
        p.y += p.vy * dt * 30.f;

        // Slow drift / slight gravity toward bottom
        p.vy += 0.0001f * dt * 30.f;

        // Slight deceleration
        p.vx *= 0.997f;
        p.vy *= 0.997f;

        // Fade
        p.life -= p.decay * dt * 30.f;

        // Kill if offscreen
        if (p.x < -0.1f || p.x > 1.1f || p.y < -0.1f || p.y > 1.1f)
            p.life = 0.f;
    }
}

// ---- Timer — CRT trace + particle update ----

void EnsembleAudioProcessorEditor::timerCallback()
{
    inputLevel = processor.getDSP().getInputLevel();
    float evolve = processor.getAPVTS().getRawParameterValue(EnsembleAudioProcessor::ID_EVOLVE)->load();
    float blend = processor.getAPVTS().getRawParameterValue(EnsembleAudioProcessor::ID_BLEND)->load();
    float t = static_cast<float>(tracePos) * 0.1f;
    traceL[tracePos % TRACE_LEN] = inputLevel * std::sin(t * 1.1f + blend * 3.f) * 0.8f;
    traceR[tracePos % TRACE_LEN] = inputLevel * std::cos(t * 0.9f + evolve * 2.f) * 0.8f;
    tracePos++;

    // Spawn particles based on audio energy
    float dt = 1.f / 30.f;
    spawnAccum += inputLevel * dt * 8.f;

    // Also spawn some ambient particles even without input (subtle life)
    spawnAccum += dt * 0.3f;

    while (spawnAccum >= 1.f) {
        spawnParticle(inputLevel, blend);
        spawnAccum -= 1.f;
    }

    // More bursts on high input
    if (inputLevel > 0.4f) {
        int burst = (int)(inputLevel * 4.f);
        for (int i = 0; i < burst; ++i)
            spawnParticle(inputLevel, blend);
    }

    updateParticles(dt);
    repaint();
}

// ---- Paint ----

void EnsembleAudioProcessorEditor::paint(juce::Graphics& g)
{
    drawEnclosure(g, getLocalBounds());
    drawCRTScreen(g, juce::Rectangle<int>(15, 12, 410, 200));
}

void EnsembleAudioProcessorEditor::drawEnclosure(juce::Graphics& g, juce::Rectangle<int> b)
{
    g.fillAll(Colors::enclosure);

    // Brushed metal texture
    g.setColour(juce::Colour(0x08FFFFFF));
    for (int y = 0; y < b.getHeight(); y += 2)
        g.drawHorizontalLine(y, 0, (float)b.getWidth());

    // Edge bevels
    g.setColour(juce::Colour(0x15FFFFFF));
    g.drawRect(b.toFloat(), 1.0f);
    g.setColour(juce::Colour(0x20000000));
    g.drawRect(b.reduced(1).toFloat(), 1.0f);

    // Corner screws
    auto drawScrew = [&](int x, int y) {
        // Shadow
        g.setColour(juce::Colour(0x30000000));
        g.fillEllipse((float)x - 4, (float)y - 3, 9, 9);
        // Body
        g.setColour(Colors::screwDark);
        g.fillEllipse((float)x - 4, (float)y - 4, 8, 8);
        // Highlight
        g.setColour(Colors::screwLight);
        g.drawEllipse((float)x - 4, (float)y - 4, 8, 8, 0.5f);
        // Phillips cross
        g.setColour(juce::Colour(0xFF0A0A0C));
        g.drawLine((float)x - 2, (float)y, (float)x + 2, (float)y, 0.8f);
        g.drawLine((float)x, (float)y - 2, (float)x, (float)y + 2, 0.8f);
    };
    drawScrew(12, 12); drawScrew(b.getWidth() - 12, 12);
    drawScrew(12, b.getHeight() - 12); drawScrew(b.getWidth() - 12, b.getHeight() - 12);

    // Title — stamped/engraved into metal
    g.setColour(juce::Colour(0xFF0E0E10)); // shadow
    g.setFont(juce::FontOptions(14.f).withStyle("Bold"));
    g.drawText("E N S E M B L E", 441, 15, 370, 20, juce::Justification::centredLeft);
    g.setColour(Colors::textDim);
    g.drawText("E N S E M B L E", 440, 14, 370, 20, juce::Justification::centredLeft);

    g.setFont(juce::FontOptions(8.5f));
    g.setColour(juce::Colour(0xFF444446));
    g.drawText("SPECTRAL TEXTURE FORGE", 440, 32, 370, 14, juce::Justification::centredLeft);

    // Section labels
    g.setFont(juce::FontOptions(8.f));
    g.setColour(Colors::textDim);
    g.drawText("WEAVE ENGINE", 440, 50, 200, 12, juce::Justification::centredLeft);
    g.drawText("MIX", 440, 160, 200, 12, juce::Justification::centredLeft);

    // Etched divider
    g.setColour(juce::Colour(0xFF2A2A2D));
    g.drawHorizontalLine(157, 435, 810);
    g.setColour(juce::Colour(0xFF111113));
    g.drawHorizontalLine(158, 435, 810);

    // EQ section
    g.setColour(Colors::textDim);
    g.drawText("12-BAND EQ", 15, 222, 200, 12, juce::Justification::centredLeft);

    // Etched divider above EQ
    g.setColour(juce::Colour(0xFF2A2A2D));
    g.drawHorizontalLine(218, 10, 810);
    g.setColour(juce::Colour(0xFF111113));
    g.drawHorizontalLine(219, 10, 810);

    // Filter section label
    g.drawText("BANDPASS", 680, 222, 100, 12, juce::Justification::centredLeft);
}

void EnsembleAudioProcessorEditor::drawCRTScreen(juce::Graphics& g, juce::Rectangle<int> area)
{
    // Outer shadow (depth)
    g.setColour(juce::Colour(0x40000000));
    g.fillRoundedRectangle(area.toFloat().translated(2, 3), 8.f);

    // Bezel — thick dark frame
    g.setColour(Colors::crtBezel);
    g.fillRoundedRectangle(area.toFloat(), 8.f);

    // Inner bezel bevel
    auto bezelInner = area.reduced(3);
    g.setColour(juce::Colour(0xFF0D0D0F));
    g.fillRoundedRectangle(bezelInner.toFloat(), 6.f);

    auto screen = area.reduced(6);
    float sx = (float)screen.getX(), sy = (float)screen.getY();
    float sw = (float)screen.getWidth(), sh = (float)screen.getHeight();

    // Screen background — very dark with subtle warm tint
    {
        juce::ColourGradient bg(
            juce::Colour(0xFF0C0808), sx, sy,
            juce::Colour(0xFF080606), sx + sw, sy + sh, false);
        g.setGradientFill(bg);
        g.fillRoundedRectangle(screen.toFloat(), 4.f);
    }

    // Scanlines
    g.setColour(juce::Colour(0x05FFFFFF));
    for (int y = screen.getY(); y < screen.getBottom(); y += 2)
        g.drawHorizontalLine(y, sx, sx + sw);

    // Grid lines (very faint)
    g.setColour(Colors::phosphorDim.withAlpha(0.2f));
    int gx = screen.getWidth() / 8, gy = screen.getHeight() / 6;
    for (int i = 1; i < 8; ++i)
        g.drawVerticalLine(screen.getX() + i * gx, sy, sy + sh);
    for (int i = 1; i < 6; ++i)
        g.drawHorizontalLine(screen.getY() + i * gy, sx, sx + sw);

    float cx = sx + sw * 0.5f, cy = sy + sh * 0.5f;

    // --- Particles (granules) ---
    for (int i = 0; i < MAX_PARTICLES; ++i) {
        const auto& p = particles[i];
        if (p.life <= 0.f) continue;

        float px = sx + p.x * sw;
        float py = sy + p.y * sh;

        // Skip if outside screen
        if (px < sx || px > sx + sw || py < sy || py > sy + sh) continue;

        float alpha = p.life * p.brightness;
        float r = p.size;

        // Outer glow (large, dim)
        float glowR = r * 3.5f;
        g.setColour(Colors::phosphorDim.withAlpha(alpha * 0.15f));
        g.fillEllipse(px - glowR, py - glowR, glowR * 2, glowR * 2);

        // Mid glow
        float midR = r * 2.0f;
        g.setColour(Colors::phosphorMed.withAlpha(alpha * 0.3f));
        g.fillEllipse(px - midR, py - midR, midR * 2, midR * 2);

        // Core (bright)
        g.setColour(Colors::phosphorBrt.withAlpha(alpha * 0.7f));
        g.fillEllipse(px - r, py - r, r * 2, r * 2);

        // Hot center for fresh particles
        if (p.life > 0.7f) {
            float hotR = r * 0.5f;
            g.setColour(Colors::phosphorHot.withAlpha((p.life - 0.7f) * 2.f));
            g.fillEllipse(px - hotR, py - hotR, hotR * 2, hotR * 2);
        }
    }

    // --- Fog / phosphor persistence layer ---
    // Dim red wash that builds with input level (simulates phosphor glow retention)
    {
        float fogAlpha = 0.02f + inputLevel * 0.06f;
        juce::ColourGradient fog(
            Colors::phosphorDim.withAlpha(fogAlpha), cx, cy,
            juce::Colours::transparentBlack, cx, sy, true);
        g.setGradientFill(fog);
        g.fillRoundedRectangle(screen.toFloat(), 4.f);
    }

    // --- Trace lines (kept but subtler, behind glass) ---
    // Trace L
    {
        juce::Path path;
        for (int i = 0; i < TRACE_LEN; ++i) {
            int idx = (tracePos + i) % TRACE_LEN;
            float x = sx + (float)i / TRACE_LEN * sw;
            float y = cy + traceL[idx] * sh * 0.35f;
            if (i == 0) path.startNewSubPath(x, y); else path.lineTo(x, y);
        }
        g.setColour(Colors::phosphorDim.withAlpha(0.25f));
        g.strokePath(path, juce::PathStrokeType(3.f));
        g.setColour(Colors::phosphorMed.withAlpha(0.5f));
        g.strokePath(path, juce::PathStrokeType(1.0f));
    }
    // Trace R
    {
        juce::Path path;
        for (int i = 0; i < TRACE_LEN; ++i) {
            int idx = (tracePos + i) % TRACE_LEN;
            float x = sx + (float)i / TRACE_LEN * sw;
            float y = cy + traceR[idx] * sh * 0.3f;
            if (i == 0) path.startNewSubPath(x, y); else path.lineTo(x, y);
        }
        g.setColour(Colors::phosphorDim.withAlpha(0.2f));
        g.strokePath(path, juce::PathStrokeType(2.5f));
        g.setColour(Colors::phosphorBrt.withAlpha(0.35f));
        g.strokePath(path, juce::PathStrokeType(0.8f));
    }

    // Input level bar
    float barW = inputLevel * sw * 0.7f;
    float barY = sy + sh - 8;
    g.setColour(Colors::phosphorDim.withAlpha(0.3f));
    g.fillRect(sx + sw * 0.15f, barY, sw * 0.7f, 3.f);
    g.setColour(inputLevel > 0.8f ? Colors::phosphorHot : Colors::phosphorMed);
    g.fillRect(sx + sw * 0.15f, barY, barW, 3.f);

    g.setColour(Colors::phosphorDim.withAlpha(0.5f));
    g.setFont(juce::FontOptions(7.f));
    g.drawText("INPUT", (int)(sx + 6), (int)(barY - 10), 36, 10, juce::Justification::centredLeft);

    // === GLASS OVERLAY ===
    // This goes on top of everything to simulate curved CRT glass

    // Main glass reflection — top-left highlight arc
    {
        juce::ColourGradient glassHL(
            juce::Colour(0x14FFFFFF), sx + sw * 0.15f, sy + sh * 0.05f,
            juce::Colours::transparentWhite, sx + sw * 0.5f, sy + sh * 0.4f, true);
        g.setGradientFill(glassHL);
        g.fillRoundedRectangle(screen.toFloat(), 4.f);
    }

    // Secondary reflection — small bright spot (lamp reflection on glass)
    {
        float spotX = sx + sw * 0.22f, spotY = sy + sh * 0.18f;
        float spotR = 18.f;
        juce::ColourGradient spot(
            juce::Colour(0x10FFFFFF), spotX, spotY,
            juce::Colours::transparentWhite, spotX + spotR, spotY + spotR, true);
        g.setGradientFill(spot);
        g.fillEllipse(spotX - spotR, spotY - spotR, spotR * 2, spotR * 2);
    }

    // Edge darkening (CRT curvature vignette)
    {
        juce::ColourGradient vignette(
            juce::Colours::transparentBlack, cx, cy,
            juce::Colour(0x30000000), sx, sy, true);
        g.setGradientFill(vignette);
        g.fillRoundedRectangle(screen.toFloat(), 4.f);
    }

    // Glass rim highlight (thin bright line along top edge)
    g.setColour(juce::Colour(0x18FFFFFF));
    g.drawHorizontalLine(screen.getY() + 1, sx + 10, sx + sw - 10);
    g.setColour(juce::Colour(0x08FFFFFF));
    g.drawHorizontalLine(screen.getY() + 2, sx + 20, sx + sw - 20);
}

// ---- Layout ----

void EnsembleAudioProcessorEditor::resized()
{
    int kW = 60, kH = 60, lblH = 13;
    auto placeKnob = [&](juce::Slider& k, juce::Label& l, int x, int y) {
        k.setBounds(x, y, kW, kH);
        l.setBounds(x, y + kH, kW, lblH);
    };

    // Weave Engine — right of CRT
    int wx = 448, wy = 58, sp = kW + 14;
    placeKnob(blendK,   blendL,   wx + 0*sp, wy);
    placeKnob(tensionK, tensionL, wx + 1*sp, wy);
    placeKnob(textureK, textureL, wx + 2*sp, wy);
    placeKnob(evolveK,  evolveL,  wx + 3*sp, wy);

    // Mix — below weave
    int my = 170;
    placeKnob(persistK, persistL, wx + 0*sp, my);
    placeKnob(inputK,   inputL,   wx + 1*sp, my);
    placeKnob(dryK,     dryL,     wx + 2*sp, my);
    placeKnob(outputK,  outputL,  wx + 3*sp, my);

    // Clear button
    clearBtn.setBounds(340, 216, 70, 22);

    // EQ sliders — bottom section, tighter
    int eqX = 18, eqY = 240;
    int eqW = 36, eqH = 130, eqSp = 46;
    for (int b = 0; b < 12; ++b) {
        eqSliders[b].setBounds(eqX + b * eqSp, eqY, eqW, eqH);
        eqLabels[b].setBounds(eqX + b * eqSp, eqY + eqH, eqW, 11);
    }

    // EQ wet knob — after sliders
    int eqWX = eqX + 12 * eqSp + 6;
    placeKnob(eqWetK, eqWetL, eqWX, eqY + 30);

    // Bandpass — far right
    int bpX = 700;
    bpToggle.setBounds(bpX, eqY + 10, 50, 22);
    placeKnob(bpFreqK, bpFreqL, bpX, eqY + 40);
}
