// PluginEditor.h — ENSEMBLE VST — Soviet CRT Interface v2
#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_gui_basics/juce_gui_basics.h>
#include "PluginProcessor.h"

class EnsembleAudioProcessorEditor : public juce::AudioProcessorEditor,
                                      private juce::Timer
{
public:
    explicit EnsembleAudioProcessorEditor(EnsembleAudioProcessor&);
    ~EnsembleAudioProcessorEditor() override;
    void paint(juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    void drawEnclosure(juce::Graphics&, juce::Rectangle<int> bounds);
    void drawCRTScreen(juce::Graphics&, juce::Rectangle<int> area);

    EnsembleAudioProcessor& processor;

    // Weave + Mix knobs
    juce::Slider blendK, tensionK, textureK, evolveK;
    juce::Slider persistK, inputK, dryK, outputK;
    juce::Label  blendL, tensionL, textureL, evolveL;
    juce::Label  persistL, inputL, dryL, outputL;

    // EQ
    juce::Slider eqSliders[12];
    juce::Label  eqLabels[12];
    juce::Slider eqWetK;
    juce::Label  eqWetL;

    // Bandpass filter
    juce::Slider bpFreqK;
    juce::Label  bpFreqL;
    juce::ToggleButton bpToggle;

    // Clear
    juce::TextButton clearBtn;

    // Attachments
    using SA = juce::AudioProcessorValueTreeState::SliderAttachment;
    using BA = juce::AudioProcessorValueTreeState::ButtonAttachment;
    std::unique_ptr<SA> blendA, tensionA, textureA, evolveA;
    std::unique_ptr<SA> persistA, inputA, dryA, outputA;
    std::unique_ptr<SA> eqA[12], eqWetA;
    std::unique_ptr<SA> bpFreqA;
    std::unique_ptr<BA> bpToggleA;

    // CRT trace
    static constexpr int TRACE_LEN = 256;
    float traceL[TRACE_LEN] = {};
    float traceR[TRACE_LEN] = {};
    int tracePos = 0;
    float inputLevel = 0.f;

    // Particle system for CRT granules
    struct Particle {
        float x, y;       // position (0-1 normalized)
        float vx, vy;     // velocity
        float life;        // 1.0 = fresh, 0.0 = dead
        float decay;       // how fast it fades
        float size;        // radius
        float brightness;  // 0-1
    };
    static constexpr int MAX_PARTICLES = 120;
    Particle particles[MAX_PARTICLES] = {};
    int nextParticle = 0;
    float spawnAccum = 0.f;   // accumulates input energy for spawning
    uint32_t rngState = 12345; // simple PRNG
    float fastRng();           // returns 0-1
    void spawnParticle(float energy, float blend);
    void updateParticles(float dt);

    void setupRotary(juce::Slider&, juce::Label&, const juce::String& text,
                     std::unique_ptr<SA>&, const juce::String& paramID);
    void setupVertical(juce::Slider&, juce::Label&, const juce::String& text,
                       std::unique_ptr<SA>&, const juce::String& paramID);

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(EnsembleAudioProcessorEditor)
};
