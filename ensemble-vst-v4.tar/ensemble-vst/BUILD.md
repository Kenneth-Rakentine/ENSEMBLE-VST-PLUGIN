# ENSEMBLE — Build & Usage Guide

## Windows Build (Visual Studio 2026)

You already have everything installed. Just rebuild with this updated code.

1. **Delete** your old build folder:
   ```
   rmdir /S /Q C:\ensemble-vst\build
   ```

2. **Replace** the `Source` folder in `C:\ensemble-vst\` with the new `Source` folder from this download.
   Also replace `CMakeLists.txt`.

3. **Make sure** `C:\ensemble-vst\CMakeLists.txt` has this line:
   ```
   set(JUCE_DIR "C:/JUCE" CACHE PATH "Path to JUCE framework")
   ```

4. **Open Developer Command Prompt for VS 2026** and run:
   ```
   cd C:\ensemble-vst
   mkdir build
   cd build
   cmake .. -G "Visual Studio 18 2026" -A x64
   cmake --build . --config Release
   ```

5. **Install:**
   ```
   xcopy /E /I "C:\ensemble-vst\build\Ensemble_artefacts\Release\VST3\ENSEMBLE.vst3" "C:\Program Files\Common Files\VST3\ENSEMBLE.vst3"
   ```

6. Rescan plugins in your DAW.

---

## macOS Build

1. Install Xcode command line tools:
   ```
   xcode-select --install
   ```

2. Install CMake:
   ```
   brew install cmake
   ```

3. Clone JUCE (if you haven't):
   ```
   git clone --depth 1 --branch 8.0.4 https://github.com/juce-framework/JUCE.git ~/juce
   ```

4. Extract `ensemble-vst-plugin.tar.gz` and edit CMakeLists.txt:
   ```
   set(JUCE_DIR "$ENV{HOME}/juce" CACHE PATH "Path to JUCE framework")
   ```

5. Build:
   ```
   cd ensemble-vst
   mkdir build && cd build
   cmake .. -DCMAKE_BUILD_TYPE=Release
   cmake --build . --config Release
   ```

6. Install:
   ```
   cp -r Ensemble_artefacts/Release/VST3/ENSEMBLE.vst3 ~/Library/Audio/Plug-Ins/VST3/
   ```

---

## Controls

### Weave Engine
- **BLEND**: Left = pointillist stippling (DUST), Right = smeared bowing (MASS)
- **TENSION**: Metallic string resonance / comb filter stress
- **TEXTURE**: How loud the weave texture is
- **EVOLVE**: How much the texture moves on its own (LFO depth)

### Mix
- **PERSIST**: Buffer feedback (0.5–0.99). Higher = denser layering over time
- **INPUT**: Input level going into the capture buffer
- **DRY**: Pass-through of your original dry signal
- **OUTPUT**: Master output level

### 12-Band EQ
- Vertical sliders: boost/cut each frequency band (±12 dB)
- **EQ MIX**: Wet/dry for the EQ (0 = EQ bypassed)

### Filter
- **FILTER**: Sweep from Low Pass → Band Pass → High Pass
- **CUTOFF**: Filter frequency. When maxed out, filter is bypassed

### Clear
- **CLEAR** button: Wipes all buffers and starts fresh

---

## Tips

- Press **CLEAR** to reset buffers and start over
- Drums don't work well — this is oriented toward melodic, harmonic, and textural sounds
- Best use case: put ENSEMBLE on your **master bus** and feed multiple sounds into it one by one
- Start with default settings, play something, and let the texture build
- Use **PERSIST** to control how dense the texture gets over time
- Turn **DRY** up if you want to hear your original signal mixed in
- The **Processing Lab** knobs all start at 0 (off) — the core engine is the weave + grains
