// test_weave.cpp
// ENSEMBLE VST — Phase 1+2+3 validation test
// Tests: Weave Engine, MASS+DUST grains, Processing Lab
// Generates WAV with full chain active for listening.

#include "../Source/DSP/EnsembleProcessor.h"
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <vector>
#include <algorithm>

struct WavWriter {
    FILE* f = nullptr;
    int channels = 2, sampleRate = 48000, dataSize = 0;
    bool open(const char* path, int sr, int ch) {
        f = fopen(path, "wb"); if (!f) return false;
        sampleRate = sr; channels = ch;
        uint8_t h[44] = {}; fwrite(h, 1, 44, f); dataSize = 0; return true;
    }
    void writeSample(float l, float r) {
        auto c = [](float v)->int16_t{ return int16_t(std::max(-1.f,std::min(1.f,v))*32767.f); };
        int16_t s[2] = {c(l),c(r)}; fwrite(s,sizeof(int16_t),2,f); dataSize+=4;
    }
    void close() {
        if(!f)return; fseek(f,0,SEEK_SET);
        uint32_t fs=36+dataSize; uint16_t bps=16,ba=channels*2; uint32_t br=sampleRate*ba;
        fwrite("RIFF",1,4,f);fwrite(&fs,4,1,f);fwrite("WAVE",1,4,f);
        fwrite("fmt ",1,4,f); uint32_t fz=16;fwrite(&fz,4,1,f);
        uint16_t fmt=1;fwrite(&fmt,2,1,f); uint16_t ch=channels;fwrite(&ch,2,1,f);
        uint32_t sr=sampleRate;fwrite(&sr,4,1,f);fwrite(&br,4,1,f);fwrite(&ba,2,1,f);fwrite(&bps,2,1,f);
        fwrite("data",1,4,f); uint32_t ds=dataSize;fwrite(&ds,4,1,f);
        fclose(f);f=nullptr;
    }
};

struct Analysis {
    float peakL=0,peakR=0; double sqL=0,sqR=0,prod=0; long n=0;
    void acc(float l,float r){peakL=std::max(peakL,std::abs(l));peakR=std::max(peakR,std::abs(r));sqL+=l*l;sqR+=r*r;prod+=l*r;n++;}
    float rmsL()const{return n?std::sqrt(float(sqL/n)):0;}
    float rmsR()const{return n?std::sqrt(float(sqR/n)):0;}
    float corr()const{double d=std::sqrt(sqL*sqR);return(d>1e-10)?float(prod/d):0;}
};

void genChord(float*bL,float*bR,int len,int sr,double*ph,float env){
    double fr[]={110.0,164.81,220.0,277.18};
    for(int i=0;i<len;++i){float sL=0,sR=0;
        for(int f=0;f<4;++f){ph[f]+=fr[f]*6.283185307/sr;float v=std::sin(float(ph[f]));
            float p=float(f)/3.f;sL+=v*(1.f-p*0.3f);sR+=v*(0.7f+p*0.3f);}
        bL[i]=sL*env*0.25f;bR[i]=sR*env*0.25f;}
}

// Run a test scenario, return Analysis
Analysis runTest(int durationSec, int inputSec, bool vocEn, bool ringEn, bool freqEn, bool filtEn) {
    constexpr int SR=48000, BLK=256;
    EnsembleProcessor proc; proc.prepare(SR,BLK);
    auto& lab = proc.getLab();

    if(vocEn){lab.vocoder.enabled=true;lab.vocoder.wet=0.5f;
        for(int b=0;b<lab.vocoder.getNumBands();++b)lab.vocoder.bandGains[b]=0.15f;
        lab.vocoder.bandGains[3]=0.85f;lab.vocoder.bandGains[5]=0.7f;}
    if(ringEn){lab.ringMod.enabled=true;lab.ringMod.wet=0.4f;}
    if(freqEn){lab.freqShift.enabled=true;lab.freqShift.shiftHz=7.f;lab.freqShift.wet=0.5f;lab.freqShift.feedback=0.25f;}
    if(filtEn){lab.filterbank.enabled=true;lab.filterbank.wet=0.4f;lab.filterbank.setRoot(110.f);lab.filterbank.setQ(10.f);}

    float bL[BLK],bR[BLK]; double ph[4]={};
    Analysis a;
    int total=durationSec*SR, inEnd=inputSec*SR;
    for(int s=0;s<total;s+=BLK){
        int n=std::min(BLK,total-s); float t=float(s)/SR;
        float env=0; if(s<inEnd){env=std::min(t*2.f,1.f);if(t>float(inputSec-1))env*=(float(inputSec)-t);}
        genChord(bL,bR,n,SR,ph,env);
        proc.processBlock(bL,bR,n);
        for(int i=0;i<n;++i)a.acc(bL[i],bR[i]);
    }
    return a;
}

int main(){
    constexpr int SR=48000,BLK=256;
    printf("ENSEMBLE VST — Phase 3 Processing Lab Test\n");
    printf("=============================================\n\n");

    // Individual module tests
    struct TestCase { const char* name; bool v,r,f,fb; };
    TestCase tests[] = {
        {"Baseline (no modules)",       false,false,false,false},
        {"Vocoder only",                true, false,false,false},
        {"Ring Mod only",               false,true, false,false},
        {"Freq Shifter only",           false,false,true, false},
        {"Filterbank only",             false,false,false,true },
        {"All modules combined",        true, true, true, true },
    };

    int allPass = 0, totalTests = 0;
    for(auto& tc : tests){
        printf("--- %s ---\n", tc.name);
        Analysis a = runTest(15, 10, tc.v, tc.r, tc.f, tc.fb);
        bool sig = a.rmsL() > 0.001f;
        bool clean = a.peakL < 1.f && a.peakR < 1.f;
        printf("  RMS: L=%.4f R=%.4f  Peak: L=%.4f R=%.4f  Corr: %.3f\n",
               a.rmsL(), a.rmsR(), a.peakL, a.peakR, a.corr());
        printf("  [%s] Signal  [%s] Clean\n\n", sig?"PASS":"FAIL", clean?"PASS":"FAIL");
        if(sig) allPass++; if(clean) allPass++;
        totalTests += 2;
    }

    // Generate full-chain WAV for listening
    printf("=== Generating full-chain WAV (25 seconds) ===\n");
    {
        EnsembleProcessor proc; proc.prepare(SR,BLK);
        auto& lab = proc.getLab();

        lab.vocoder.enabled=true; lab.vocoder.wet=0.35f;
        for(int b=0;b<lab.vocoder.getNumBands();++b)lab.vocoder.bandGains[b]=0.2f;
        lab.vocoder.bandGains[3]=0.8f; lab.vocoder.bandGains[5]=0.65f;

        lab.ringMod.enabled=true; lab.ringMod.wet=0.2f; lab.ringMod.model=RingModulator::Diode;
        lab.freqShift.enabled=true; lab.freqShift.shiftHz=3.f; lab.freqShift.wet=0.25f; lab.freqShift.feedback=0.12f;
        lab.filterbank.enabled=true; lab.filterbank.wet=0.25f; lab.filterbank.setRoot(110.f); lab.filterbank.setQ(8.f);

        float bL[BLK],bR[BLK]; double ph[4]={};
        Analysis full,tail;
        WavWriter wav; wav.open("ensemble_phase3.wav",SR,2);

        int total=25*SR, inEnd=12*SR, tailStart=20*SR;
        for(int s=0;s<total;s+=BLK){
            int n=std::min(BLK,total-s); float t=float(s)/SR;
            float env=0; if(s<inEnd){env=std::min(t*2.f,1.f);if(t>11.f)env*=(12.f-t);}
            genChord(bL,bR,n,SR,ph,env);
            proc.processBlock(bL,bR,n);
            for(int i=0;i<n;++i){
                wav.writeSample(bL[i],bR[i]);
                full.acc(bL[i],bR[i]);
                if(s+i>=tailStart) tail.acc(bL[i],bR[i]);
            }
        }
        wav.close();

        printf("\nFULL 25s:  RMS L=%.4f R=%.4f  Peak L=%.4f R=%.4f  Corr: %.3f\n",
               full.rmsL(),full.rmsR(),full.peakL,full.peakR,full.corr());
        printf("TAIL 5s:   RMS L=%.4f R=%.4f  Peak L=%.4f R=%.4f  Corr: %.3f\n",
               tail.rmsL(),tail.rmsR(),tail.peakL,tail.peakR,tail.corr());

        bool persist = tail.rmsL() > 0.001f;
        bool wide = tail.corr() < 0.7f;
        bool clean = full.peakL < 1.f && full.peakR < 1.f;

        printf("\n[%s] Texture persists after input stops\n", persist?"PASS":"FAIL");
        printf("[%s] Wide stereo field\n", wide?"PASS":"FAIL");
        printf("[%s] No clipping in full chain\n", clean?"PASS":"FAIL");

        if(persist)allPass++; if(wide)allPass++; if(clean)allPass++;
        totalTests+=3;
    }

    printf("\n=== RESULTS: %d/%d tests passed ===\n", allPass, totalTests);
    if(allPass==totalTests) printf(">>> ALL PHASE 3 TESTS PASSED <<<\n");
    else printf(">>> %d TESTS FAILED <<<\n", totalTests-allPass);

    printf("\nOutput: ensemble_phase3.wav\n");
    return 0;
}
