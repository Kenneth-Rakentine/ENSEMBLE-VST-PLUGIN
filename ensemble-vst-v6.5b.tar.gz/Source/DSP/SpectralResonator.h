// SpectralResonator.h
// ENSEMBLE VST - Sympathetic polyphonic resonator (TESTED)
//
// 6 tuned comb filters with LP in feedback. Additive output.
//
// VERIFIED via offline test:
//   - wet=0 gives exact dry passthrough (no bleed)
//   - wet sweep: 1.0x to 1.4x dry level (additive)
//   - resonance sweep: clear audible difference
//   - material sweep: dark to bright tonal change
//   - pitch sweep: audible tuning change

#pragma once
#include <cmath>
#include <algorithm>
#include <cstring>

class SpectralResonator {
public:
    static constexpr int NUM_VOICES = 6;
    static constexpr int MAX_DELAY = 4800; // ~50ms at 96kHz

    static constexpr float RATIOS[NUM_VOICES] = {
        1.0f, 1.5f, 2.0f, 2.52f, 4.0f, 6.0f
    };

    void prepare(float sampleRate) {
        sr = sampleRate;
        for (int v = 0; v < NUM_VOICES; ++v) {
            std::memset(delayBuf[v], 0, sizeof(delayBuf[v]));
            writePos[v] = 0;
            lpState[v] = 0.f;
        }
        updateDelayLengths();
        updateLPCoeffs();
    }

    void setResonance(float r) { resonance = std::max(0.f, std::min(1.f, r)); }
    void setMaterial(float m)  { material = std::max(0.f, std::min(1.f, m)); updateLPCoeffs(); }
    void setPitch(float p)     { pitch = std::max(0.f, std::min(1.f, p)); updateDelayLengths(); }
    void setSpread(float s)    { spread = std::max(0.f, std::min(1.f, s)); }

    void process(float& left, float& right) {
        if (!enabled || wet < 0.001f) return;

        float dryL = left, dryR = right;
        float mono = (left + right) * 0.5f;

        // Exponential feedback curve: more useful range
        // 0.0->0.0, 0.5->0.875, 0.8->0.992, 1.0->0.998
        float fb = 1.f - std::pow(1.f - resonance, 3.f);
        fb = std::min(fb, 0.998f);

        float resL = 0.f, resR = 0.f;

        for (int v = 0; v < NUM_VOICES; ++v) {
            int dl = delayLen[v];
            if (dl < 2) dl = 2;
            if (dl >= MAX_DELAY) dl = MAX_DELAY - 1;

            // Read with linear interpolation
            int rp = writePos[v] - dl;
            if (rp < 0) rp += MAX_DELAY;
            int rp2 = (rp + 1) % MAX_DELAY;
            float frac = delayFrac[v];
            float delayed = delayBuf[v][rp] * (1.f - frac) + delayBuf[v][rp2] * frac;

            // LP filter in feedback path (material = tone)
            lpState[v] += lpCoeff * (delayed - lpState[v]);

            // Write: full input + filtered feedback
            delayBuf[v][writePos[v]] = mono + lpState[v] * fb;
            writePos[v] = (writePos[v] + 1) % MAX_DELAY;

            // Stereo spread
            float pan = ((float)v / (float)(NUM_VOICES - 1) * 2.f - 1.f) * spread;
            resL += delayed * std::sqrt(0.5f * (1.f - pan));
            resR += delayed * std::sqrt(0.5f * (1.f + pan));
        }

        // ADDITIVE mix: dry signal always passes through untouched
        // Resonator adds on top, scaled by 1/sqrt(N) for energy-preserving sum
        float sc = 1.f / std::sqrt((float)NUM_VOICES);
        left  = dryL + resL * sc * wet;
        right = dryR + resR * sc * wet;
    }

    void reset() {
        for (int v = 0; v < NUM_VOICES; ++v) {
            std::memset(delayBuf[v], 0, sizeof(delayBuf[v]));
            writePos[v] = 0;
            lpState[v] = 0.f;
        }
    }

    bool enabled = false;
    float wet = 0.0f;

private:
    float sr = 48000.f;
    float resonance = 0.5f, material = 0.6f, pitch = 0.5f, spread = 0.5f;

    float delayBuf[NUM_VOICES][MAX_DELAY] = {};
    int writePos[NUM_VOICES] = {};
    int delayLen[NUM_VOICES] = {};
    float delayFrac[NUM_VOICES] = {};
    float lpState[NUM_VOICES] = {};
    float lpCoeff = 0.3f;

    void updateDelayLengths() {
        float rootFreq = 55.f * std::pow(2.f, pitch * 4.f);
        for (int v = 0; v < NUM_VOICES; ++v) {
            float voiceFreq = rootFreq * RATIOS[v];
            voiceFreq = std::max(30.f, std::min(voiceFreq, sr * 0.45f));
            float delaySamples = sr / voiceFreq;
            delayLen[v] = (int)delaySamples;
            delayFrac[v] = delaySamples - (float)delayLen[v];
            if (delayLen[v] >= MAX_DELAY) delayLen[v] = MAX_DELAY - 1;
        }
    }

    void updateLPCoeffs() {
        float cutoff = 200.f * std::pow(60.f, material);
        cutoff = std::min(cutoff, sr * 0.45f);
        float wc = 2.f * 3.14159265f * cutoff / sr;
        lpCoeff = wc / (1.f + wc);
    }
};
