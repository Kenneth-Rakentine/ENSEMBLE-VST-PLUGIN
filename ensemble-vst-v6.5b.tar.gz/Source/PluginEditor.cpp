// PluginEditor.cpp - ENSEMBLE VST v6.5b
#include "PluginEditor.h"
#include <cmath>

namespace C {
    const juce::Colour bg(0xFF0F0F11), panel(0xFF1C1B1F), panelLt(0xFF252428);
    const juce::Colour well(0xFF080808), bevelLt(0xFF3A3840), bevelDk(0xFF0A0A0C);
    const juce::Colour border(0xFF2E2C30);
    const juce::Colour knobTop(0xFF343238), knobBot(0xFF1A1820), knobRim(0xFF4A4850), knobIn(0xFF0C0C0E);
    const juce::Colour ruby(0xFF70000E), rubyDim(0xFF3A0008);
    const juce::Colour txtDim(0xFF5A5860), txtMed(0xFF8A8890), txtBrt(0xFFCAC8CE), txtCream(0xFFC8B9A0);
    const juce::Colour fdrTrack(0xFF0A0A0C), fdrThumb(0xFF4A4850), fdrThLt(0xFF5E5C64);
    const juce::Colour crtBg(0xFF080606), crtGrid(0xFF261010), crtDim(0xFF3A0808);
    const juce::Colour crtMed(0xFFAA2222), crtBrt(0xFFEE3333), crtHot(0xFFFF6644), crtBezel(0xFF2A2830);
    const juce::Colour togOn(0xFFC8B9A0), togOff(0xFF3A3840);
    const juce::Colour ledOn(0xFFDD8833), ledOff(0xFF332811), btnFace(0xFF222024);
}

// === LAYOUT ===
static constexpr int W = 780, H = 460;
static constexpr int crtX = 20, crtY = 20, crtW = 340, crtH = 170;
static constexpr int titleY = 198;
static constexpr int kR = 26, kX0 = 420, kDx = 86, kY1 = 72, kY2 = 184;

// All 3 bottom panels: same top & same height
// MIX knob values end around y=230, so start panels at 248 with 4px gap
static constexpr int panY = 248;
static constexpr int panH = 194;  // all panels same height, bottom at 442

// EQ panel
static constexpr int eqPX = 16, eqPW = 382;
static constexpr int eqTop = 284, eqBot = 400, eqX0 = 38, eqDx = 31;

// Resonator panel
static constexpr int resPX = 404, resPW = 176;
// Faders start further right to give labels more room
static constexpr int resFdrL = 460, resFdrR = 572;
static constexpr int resY0 = 280, resDy = 24;

// Controls column
static constexpr int ctlPX = 586, ctlPW = 180;
static constexpr int ctlFdrL = 660, ctlFdrR = 754;

static const char* eqLbl[12]={"60","120","250","500","1k","2k","3k","4k","6k","8k","12k","16k"};
static const char* resLbl[5]={"RESO","MATRL","PITCH","SPRD","WET"};

// === CONSTRUCTOR ===
EnsembleAudioProcessorEditor::EnsembleAudioProcessorEditor(EnsembleAudioProcessor& p)
    : AudioProcessorEditor(&p), proc(p)
{
    mkRotary(blendK,blendA,EnsembleAudioProcessor::ID_BLEND);
    mkRotary(tensionK,tensionA,EnsembleAudioProcessor::ID_TENSION);
    mkRotary(textureK,textureA,EnsembleAudioProcessor::ID_TEXTURE);
    mkRotary(evolveK,evolveA,EnsembleAudioProcessor::ID_EVOLVE);
    mkRotary(persistK,persistA,EnsembleAudioProcessor::ID_PERSIST);
    mkRotary(inputK,inputA,EnsembleAudioProcessor::ID_INPUT);
    mkRotary(dryK,dryA,EnsembleAudioProcessor::ID_DRY);
    mkRotary(outputK,outputA,EnsembleAudioProcessor::ID_OUTPUT);
    for(int b=0;b<12;++b) mkLinear(eqSliders[b],eqA[b],EnsembleAudioProcessor::ID_EQ[b]);
    mkHLinear(resResoS,resResoA,EnsembleAudioProcessor::ID_RES_RESO);
    mkHLinear(resMatS,resMatA,EnsembleAudioProcessor::ID_RES_MAT);
    mkHLinear(resPitchS,resPitchA,EnsembleAudioProcessor::ID_RES_PITCH);
    mkHLinear(resSpreadS,resSpreadA,EnsembleAudioProcessor::ID_RES_SPREAD);
    mkHLinear(resWetS,resWetA,EnsembleAudioProcessor::ID_RES_WET);
    mkHLinear(eqWetS,eqWetA,EnsembleAudioProcessor::ID_EQ_WET);
    mkHLinear(bpFreqS,bpFreqA,EnsembleAudioProcessor::ID_BP_FREQ);
    bpToggle.setAlpha(0.0f); addAndMakeVisible(bpToggle);
    bpToggleA = std::make_unique<BA>(proc.getAPVTS(),EnsembleAudioProcessor::ID_BP_ENABLED,bpToggle);
    clearBtn.setAlpha(0.0f);
    clearBtn.onClick=[this](){proc.requestClear();repaint();};
    addAndMakeVisible(clearBtn);
    setSize(W,H); startTimerHz(30);
}
EnsembleAudioProcessorEditor::~EnsembleAudioProcessorEditor(){}

void EnsembleAudioProcessorEditor::mkRotary(juce::Slider&s,std::unique_ptr<SA>&a,const juce::String&pid){
    s.setSliderStyle(juce::Slider::RotaryVerticalDrag);s.setTextBoxStyle(juce::Slider::NoTextBox,true,0,0);
    s.setAlpha(0.0f);addAndMakeVisible(s);a=std::make_unique<SA>(proc.getAPVTS(),pid,s);}
void EnsembleAudioProcessorEditor::mkLinear(juce::Slider&s,std::unique_ptr<SA>&a,const juce::String&pid){
    s.setSliderStyle(juce::Slider::LinearVertical);s.setTextBoxStyle(juce::Slider::NoTextBox,true,0,0);
    s.setAlpha(0.0f);addAndMakeVisible(s);a=std::make_unique<SA>(proc.getAPVTS(),pid,s);}
void EnsembleAudioProcessorEditor::mkHLinear(juce::Slider&s,std::unique_ptr<SA>&a,const juce::String&pid){
    s.setSliderStyle(juce::Slider::LinearHorizontal);s.setTextBoxStyle(juce::Slider::NoTextBox,true,0,0);
    s.setAlpha(0.0f);addAndMakeVisible(s);a=std::make_unique<SA>(proc.getAPVTS(),pid,s);}

// === PARTICLES ===
float EnsembleAudioProcessorEditor::fr(){rng=rng*1664525u+1013904223u;return(float)(rng>>8)/16777216.f;}
void EnsembleAudioProcessorEditor::spawn(float e,float b){
    auto&p=ps[nxP];nxP=(nxP+1)%NP;p.x=0.15f+fr()*0.7f;p.y=0.15f+fr()*0.7f;
    float a=fr()*6.2832f,sp=0.002f+e*0.018f;
    p.vx=std::cos(a)*sp+(fr()-0.5f)*0.005f;p.vy=std::sin(a)*sp+(fr()-0.5f)*0.005f;
    p.sz=0.6f+b*2.5f+fr()*1.8f;p.life=1.0f;p.dec=0.005f+fr()*0.014f;p.brt=0.3f+e*0.7f;}
void EnsembleAudioProcessorEditor::tick(float dt){
    float f=dt*30.f;for(int i=0;i<NP;++i){auto&p=ps[i];if(p.life<=0.f)continue;
    p.x+=p.vx*f;p.y+=p.vy*f;p.vy+=0.00007f*f;p.vx*=0.997f;p.vy*=0.997f;p.life-=p.dec*f;
    if(p.x<-0.1f||p.x>1.1f||p.y<-0.1f||p.y>1.1f)p.life=0.f;}}
void EnsembleAudioProcessorEditor::timerCallback(){
    inLvl=proc.getDSP().getInputLevel();
    float bl=proc.getAPVTS().getRawParameterValue(EnsembleAudioProcessor::ID_BLEND)->load();
    float ev=proc.getAPVTS().getRawParameterValue(EnsembleAudioProcessor::ID_EVOLVE)->load();
    float t=(float)trPos*0.1f,amp=std::min(inLvl*5.0f,1.0f);
    trL[trPos%TRACE]=amp*std::sin(t*1.1f+bl*3.f)*0.9f;
    trR[trPos%TRACE]=amp*std::cos(t*0.9f+ev*2.f)*0.9f;trPos++;
    float dt=1.f/30.f;spAcc+=dt*1.0f+inLvl*dt*14.f;
    while(spAcc>=1.f){spawn(inLvl,bl);spAcc-=1.f;}
    if(inLvl>0.25f)for(int i=0;i<(int)(inLvl*6.f);++i)spawn(inLvl,bl);
    tick(dt);repaint();}

// === DRAW HELPERS ===
void EnsembleAudioProcessorEditor::drawPanel(juce::Graphics&g,juce::Rectangle<float>r,float corner){
    g.setColour(juce::Colours::black.withAlpha(0.35f));g.fillRoundedRectangle(r.translated(2.f,2.f),corner);
    juce::ColourGradient grad(C::panelLt,r.getX(),r.getY(),C::panel,r.getX(),r.getBottom(),false);
    g.setGradientFill(grad);g.fillRoundedRectangle(r,corner);
    g.setColour(C::bevelLt.withAlpha(0.2f));g.drawRoundedRectangle(r.reduced(0.5f),corner,0.7f);}

void EnsembleAudioProcessorEditor::drawKnob(juce::Graphics&g,juce::Slider&slider,int cx,int cy,int r,const char*label){
    float nv=(float)slider.valueToProportionOfLength(slider.getValue());
    const float pi=juce::MathConstants<float>::pi;
    const float jS=1.25f*pi,jW=1.5f*pi,jE=jS+jW,jV=jS+nv*jW,sV=jV-pi*0.5f;
    float arcR=(float)r+5.f;
    g.setColour(C::well);g.fillEllipse((float)(cx-r-7),(float)(cy-r-7),(float)(r+7)*2.f,(float)(r+7)*2.f);
    {juce::Path trk;trk.addCentredArc((float)cx,(float)cy,arcR,arcR,0.f,jS,jE,true);
     g.setColour(C::border);g.strokePath(trk,juce::PathStrokeType(2.5f,juce::PathStrokeType::curved,juce::PathStrokeType::rounded));}
    if(nv>0.005f){juce::Path vp;vp.addCentredArc((float)cx,(float)cy,arcR,arcR,0.f,jS,jV,true);
     g.setColour(C::ruby);g.strokePath(vp,juce::PathStrokeType(2.5f,juce::PathStrokeType::curved,juce::PathStrokeType::rounded));}
    {juce::ColourGradient kg(C::knobTop,(float)cx,(float)(cy-r),C::knobBot,(float)cx,(float)(cy+r),false);
     g.setGradientFill(kg);g.fillEllipse((float)(cx-r),(float)(cy-r),(float)r*2.f,(float)r*2.f);}
    g.setColour(C::knobRim.withAlpha(0.5f));
    g.drawEllipse((float)(cx-r)+0.5f,(float)(cy-r)+0.5f,(float)r*2.f-1.f,(float)r*2.f-1.f,1.2f);
    float iR=(float)r*0.62f;
    {juce::ColourGradient ig(C::knobIn,(float)cx,(float)(cy-iR*0.5f),C::knobBot.withAlpha(0.6f),(float)cx,(float)(cy+iR),false);
     g.setGradientFill(ig);g.fillEllipse((float)cx-iR,(float)cy-iR,iR*2.f,iR*2.f);}
    g.setColour(C::bevelDk.withAlpha(0.35f));g.drawEllipse((float)cx-iR+0.5f,(float)cy-iR+0.5f,iR*2.f-1.f,iR*2.f-1.f,0.5f);
    float pIn=(float)r*0.28f,pOut=(float)r*0.9f;
    float px1=(float)cx+std::cos(sV)*pIn,py1=(float)cy+std::sin(sV)*pIn;
    float px2=(float)cx+std::cos(sV)*pOut,py2=(float)cy+std::sin(sV)*pOut;
    g.setColour(C::txtCream);g.drawLine(px1,py1,px2,py2,2.f);g.fillEllipse(px2-2.f,py2-2.f,4.f,4.f);
    g.setColour(C::txtDim);g.setFont(juce::FontOptions(9.f));
    g.drawText(label,cx-36,cy+r+8,72,12,juce::Justification::centred);
    g.setColour(C::txtMed);g.setFont(juce::FontOptions(10.f));
    juce::String vt=slider.getMaximum()>100.0?juce::String((int)slider.getValue()):juce::String(slider.getValue(),2);
    g.drawText(vt,cx-28,cy+r+20,56,12,juce::Justification::centred);}

void EnsembleAudioProcessorEditor::drawFader(juce::Graphics&g,juce::Slider&s,int cx,int top,int bot){
    float nv=(float)s.valueToProportionOfLength(s.getValue()),tY=(float)bot-nv*(float)(bot-top);
    g.setColour(C::fdrTrack);g.fillRoundedRectangle((float)cx-2.f,(float)top,4.f,(float)(bot-top),2.f);
    if(nv>0.01f){g.setColour(C::rubyDim);g.fillRoundedRectangle((float)cx-1.5f,tY,3.f,(float)bot-tY,1.5f);}
    g.setColour(C::border.withAlpha(0.5f));g.drawHorizontalLine((int)((float)(top+bot)/2.f),(float)(cx-5),(float)(cx+5));
    float tw=16.f,th=9.f;
    {juce::ColourGradient tg(C::fdrThLt,(float)cx,tY-th/2.f,C::fdrThumb,(float)cx,tY+th/2.f,false);
     g.setGradientFill(tg);g.fillRoundedRectangle((float)cx-tw/2.f,tY-th/2.f,tw,th,3.f);}
    g.setColour(C::knobRim.withAlpha(0.4f));g.drawRoundedRectangle((float)cx-tw/2.f,tY-th/2.f,tw,th,3.f,0.5f);}

void EnsembleAudioProcessorEditor::drawHFader(juce::Graphics&g,juce::Slider&s,int left,int right,int cy){
    float nv=(float)s.valueToProportionOfLength(s.getValue()),tX=(float)left+nv*(float)(right-left);
    g.setColour(C::fdrTrack);g.fillRoundedRectangle((float)left,(float)cy-2,float(right-left),4.f,2.f);
    if(nv>0.01f){g.setColour(C::rubyDim);g.fillRoundedRectangle((float)left,(float)cy-1.5f,tX-(float)left,3.f,1.5f);}
    float tw=9.f,th=14.f;
    {juce::ColourGradient tg(C::fdrThLt,tX-tw/2.f,(float)cy,C::fdrThumb,tX+tw/2.f,(float)cy,false);
     g.setGradientFill(tg);g.fillRoundedRectangle(tX-tw/2.f,(float)cy-th/2.f,tw,th,3.f);}
    g.setColour(C::knobRim.withAlpha(0.4f));g.drawRoundedRectangle(tX-tw/2.f,(float)cy-th/2.f,tw,th,3.f,0.5f);}

// === CRT ===
void EnsembleAudioProcessorEditor::drawCRT(juce::Graphics&g,juce::Rectangle<int>a){
    float sx=(float)a.getX(),sy=(float)a.getY(),sw=(float)a.getWidth(),sh=(float)a.getHeight();
    float cx=sx+sw*0.5f,cy=sy+sh*0.5f;
    g.setColour(C::crtBezel);g.fillRoundedRectangle(sx-5,sy-5,sw+10,sh+10,6.f);
    g.setColour(C::bevelLt.withAlpha(0.15f));g.drawRoundedRectangle(sx-5.5f,sy-5.5f,sw+11.f,sh+11.f,6.f,0.8f);
    g.setColour(C::crtBg);g.fillRoundedRectangle(sx,sy,sw,sh,3.f);
    g.setColour(juce::Colour(0x05FFFFFF));for(int y=a.getY();y<a.getBottom();y+=2)g.drawHorizontalLine(y,sx,sx+sw);
    g.setColour(C::crtGrid.withAlpha(0.85f));
    for(int i=1;i<8;++i)g.drawVerticalLine((int)(sx+(float)i*sw/8.f),sy+2,sy+sh-2);
    for(int i=1;i<4;++i)g.drawHorizontalLine((int)(sy+(float)i*sh/4.f),sx+2,sx+sw-2);
    g.setColour(C::crtGrid.withAlpha(1.0f));g.drawHorizontalLine((int)cy,sx+2,sx+sw-2);g.drawVerticalLine((int)cx,sy+2,sy+sh-2);
    for(int i=0;i<NP;++i){const auto&p=ps[i];if(p.life<=0.f)continue;
        float px=sx+p.x*sw,py=sy+p.y*sh;if(px<sx+2||px>sx+sw-2||py<sy+2||py>sy+sh-2)continue;
        float al=p.life*p.brt;float r=p.sz;
        g.setColour(C::crtDim.withAlpha(al*0.1f));g.fillEllipse(px-r*4,py-r*4,r*8,r*8);
        g.setColour(C::crtMed.withAlpha(al*0.22f));g.fillEllipse(px-r*2,py-r*2,r*4,r*4);
        g.setColour(C::crtBrt.withAlpha(al*0.55f));g.fillEllipse(px-r,py-r,r*2,r*2);
        if(p.life>0.65f){float hr=r*0.4f;g.setColour(C::crtHot.withAlpha((p.life-0.65f)*2.f));g.fillEllipse(px-hr,py-hr,hr*2,hr*2);}}
    float fog=0.012f+inLvl*0.06f;
    juce::ColourGradient fg(C::crtDim.withAlpha(fog),cx,cy,juce::Colours::transparentBlack,cx,sy,true);
    g.setGradientFill(fg);g.fillRect(a);
    auto trace=[&](float*buf,float ysc,juce::Colour d,float dw,juce::Colour b,float bw){
        juce::Path p;for(int i=0;i<TRACE;++i){int idx=(trPos+i)%TRACE;
        float x=sx+4+(float)i/TRACE*(sw-8),y=cy+buf[idx]*sh*ysc;
        if(i==0)p.startNewSubPath(x,y);else p.lineTo(x,y);}
        g.setColour(d);g.strokePath(p,juce::PathStrokeType(dw));g.setColour(b);g.strokePath(p,juce::PathStrokeType(bw));};
    trace(trL,0.4f,C::crtDim.withAlpha(0.25f),3.5f,C::crtMed.withAlpha(0.55f),1.3f);
    trace(trR,0.35f,C::crtDim.withAlpha(0.18f),3.f,C::crtBrt.withAlpha(0.4f),0.9f);
    float bw=inLvl*sw*0.7f,by=sy+sh-7;
    g.setColour(C::crtDim.withAlpha(0.25f));g.fillRoundedRectangle(sx+sw*0.15f,by,sw*0.7f,3.f,1.5f);
    g.setColour(inLvl>0.8f?C::crtHot:C::crtMed);g.fillRoundedRectangle(sx+sw*0.15f,by,bw,3.f,1.5f);
    juce::ColourGradient gl(juce::Colours::white.withAlpha(0.04f),sx+25,sy+15,juce::Colours::transparentWhite,cx,cy,true);
    g.setGradientFill(gl);g.fillRoundedRectangle(sx,sy,sw,sh,3.f);
    g.setColour(C::bevelDk);g.drawRoundedRectangle(sx+0.5f,sy+0.5f,sw-1,sh-1,3.f,1.5f);}

// === PAINT ===
void EnsembleAudioProcessorEditor::paint(juce::Graphics&g){
    g.fillAll(C::bg);
    drawPanel(g,juce::Rectangle<float>(8,8,W-16,H-16).toFloat(),10.f);
    drawCRT(g,{crtX,crtY,crtW,crtH});

    g.setColour(C::txtBrt);g.setFont(juce::FontOptions(14.f));
    g.drawText("E N S E M B L E",crtX,titleY,crtW,16,juce::Justification::centred);
    g.setColour(C::txtDim);g.setFont(juce::FontOptions(8.5f));
    g.drawText("SPECTRAL TEXTURE ENGINE",crtX,titleY+15,crtW,12,juce::Justification::centred);

    // WEAVE ENGINE
    g.setColour(C::txtCream);g.setFont(juce::FontOptions(9.f));
    g.drawText("WEAVE ENGINE",kX0-48,kY1-kR-28,200,12,juce::Justification::centredLeft);
    g.setColour(C::rubyDim.withAlpha(0.5f));g.fillRect((float)(kX0-48),(float)(kY1-kR-15),336.f,1.f);
    drawKnob(g,blendK,kX0,kY1,kR,"BLEND");drawKnob(g,tensionK,kX0+kDx,kY1,kR,"TENSION");
    drawKnob(g,textureK,kX0+kDx*2,kY1,kR,"TEXTURE");drawKnob(g,evolveK,kX0+kDx*3,kY1,kR,"EVOLVE");

    // MIX
    g.setColour(C::txtCream);g.setFont(juce::FontOptions(9.f));
    g.drawText("MIX",kX0-48,kY2-kR-28,100,12,juce::Justification::centredLeft);
    g.setColour(C::rubyDim.withAlpha(0.5f));g.fillRect((float)(kX0-48),(float)(kY2-kR-15),336.f,1.f);
    drawKnob(g,persistK,kX0,kY2,kR,"PERSIST");drawKnob(g,inputK,kX0+kDx,kY2,kR,"INPUT");
    drawKnob(g,dryK,kX0+kDx*2,kY2,kR,"DRY");drawKnob(g,outputK,kX0+kDx*3,kY2,kR,"OUTPUT");

    // === EQ PANEL ===
    drawPanel(g,juce::Rectangle<float>((float)eqPX,(float)panY,(float)eqPW,(float)panH).toFloat(),6.f);
    g.setColour(C::txtDim);g.setFont(juce::FontOptions(8.f));
    g.drawText("12-BAND EQ",eqPX+12,panY+5,120,10,juce::Justification::centredLeft);
    for(int b=0;b<12;++b){int fx=eqX0+b*eqDx;drawFader(g,eqSliders[b],fx,eqTop,eqBot);
        g.setColour(C::txtDim);g.setFont(juce::FontOptions(6.5f));
        g.drawText(eqLbl[b],fx-14,eqBot+4,28,10,juce::Justification::centred);}

    // === RESONATOR PANEL (same height as EQ and Controls) ===
    drawPanel(g,juce::Rectangle<float>((float)resPX,(float)panY,(float)resPW,(float)panH).toFloat(),6.f);
    g.setColour(C::txtDim);g.setFont(juce::FontOptions(8.f));
    g.drawText("RESONATOR",resPX+10,panY+5,100,10,juce::Justification::centredLeft);
    juce::Slider* resSliders[5]={&resResoS,&resMatS,&resPitchS,&resSpreadS,&resWetS};
    for(int i=0;i<5;++i){int fy=resY0+i*resDy;
        g.setColour(C::txtDim);g.setFont(juce::FontOptions(7.f));
        // Labels with extra right padding (drawn right-justified in wider area)
        g.drawText(resLbl[i],resPX+4,fy-6,50,12,juce::Justification::centredRight);
        drawHFader(g,*resSliders[i],resFdrL,resFdrR,fy);}

    // === CONTROLS PANEL ===
    drawPanel(g,juce::Rectangle<float>((float)ctlPX,(float)panY,(float)ctlPW,(float)panH).toFloat(),6.f);
    g.setColour(C::txtDim);g.setFont(juce::FontOptions(8.f));
    g.drawText("CONTROLS",ctlPX+10,panY+5,80,10,juce::Justification::centredLeft);

    int cy1=panY+34,cy2=panY+62;
    g.setColour(C::txtDim);g.setFont(juce::FontOptions(7.f));
    g.drawText("EQ MIX",ctlPX+8,cy1-6,50,12,juce::Justification::centredLeft);
    drawHFader(g,eqWetS,ctlFdrL,ctlFdrR,cy1);
    g.drawText("BP FREQ",ctlPX+8,cy2-6,50,12,juce::Justification::centredLeft);
    drawHFader(g,bpFreqS,ctlFdrL,ctlFdrR,cy2);

    // BP Toggle
    {bool on=bpToggle.getToggleState();
     int tx=ctlPX+ctlPW/2,ty=panY+100;
     g.setColour(C::well);g.fillRoundedRectangle((float)tx-14,(float)ty-10,28.f,20.f,4.f);
     g.setColour(C::border);g.drawRoundedRectangle((float)tx-14,(float)ty-10,28.f,20.f,4.f,0.6f);
     float lx=on?(float)tx+5:(float)tx-5;
     g.setColour(on?C::togOn:C::togOff);g.fillEllipse(lx-6,(float)ty-6,12.f,12.f);
     g.setColour(on?C::ledOn:C::ledOff);g.fillEllipse((float)tx-3,(float)ty-20,6.f,6.f);
     if(on){g.setColour(C::ledOn.withAlpha(0.12f));g.fillEllipse((float)tx-9,(float)ty-26,18.f,18.f);}
     g.setColour(C::txtDim);g.setFont(juce::FontOptions(8.f));
     g.drawText("BANDPASS",tx-30,ty+14,60,10,juce::Justification::centred);}

    // CLEAR
    {bool down=clearBtn.isDown();
     float bx=(float)(ctlPX+ctlPW/2-28),by=(float)(panY+150);
     g.setColour(down?C::rubyDim:C::btnFace);g.fillRoundedRectangle(bx,by,56.f,20.f,4.f);
     g.setColour(C::ruby.withAlpha(0.6f));g.drawRoundedRectangle(bx,by,56.f,20.f,4.f,0.8f);
     g.setColour(down?C::txtBrt:C::txtMed);g.setFont(juce::FontOptions(9.f));
     g.drawText("CLEAR",(int)bx,(int)by,56,20,juce::Justification::centred);}
}

// === LAYOUT ===
void EnsembleAudioProcessorEditor::resized(){
    int kH=kR+10;
    auto pk=[&](juce::Slider&s,int cx,int cy){s.setBounds(cx-kH,cy-kH,kH*2,kH*2);};
    pk(blendK,kX0,kY1);pk(tensionK,kX0+kDx,kY1);pk(textureK,kX0+kDx*2,kY1);pk(evolveK,kX0+kDx*3,kY1);
    pk(persistK,kX0,kY2);pk(inputK,kX0+kDx,kY2);pk(dryK,kX0+kDx*2,kY2);pk(outputK,kX0+kDx*3,kY2);

    for(int b=0;b<12;++b){int fx=eqX0+b*eqDx;eqSliders[b].setBounds(fx-12,eqTop-4,24,eqBot-eqTop+8);}

    juce::Slider* resSliders[5]={&resResoS,&resMatS,&resPitchS,&resSpreadS,&resWetS};
    for(int i=0;i<5;++i){int fy=resY0+i*resDy;resSliders[i]->setBounds(resFdrL-4,fy-8,resFdrR-resFdrL+8,16);}

    eqWetS.setBounds(ctlFdrL-4,panY+34-8,ctlFdrR-ctlFdrL+8,16);
    bpFreqS.setBounds(ctlFdrL-4,panY+62-8,ctlFdrR-ctlFdrL+8,16);

    int tx=ctlPX+ctlPW/2;
    bpToggle.setBounds(tx-16,panY+90,32,28);
    clearBtn.setBounds(ctlPX+ctlPW/2-28,panY+150,56,20);
}
