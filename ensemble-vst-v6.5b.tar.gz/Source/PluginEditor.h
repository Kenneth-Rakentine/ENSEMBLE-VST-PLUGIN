// PluginEditor.h - ENSEMBLE VST v6.5b
#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_gui_basics/juce_gui_basics.h>
#include "PluginProcessor.h"

class EnsembleAudioProcessorEditor : public juce::AudioProcessorEditor,
                                      private juce::Timer
{
public:
    explicit EnsembleAudioProcessorEditor(EnsembleAudioProcessor&);
    ~EnsembleAudioProcessorEditor() override;
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    void timerCallback() override;
    void drawPanel(juce::Graphics&, juce::Rectangle<float> r, float corner = 6.f);
    void drawKnob(juce::Graphics&, juce::Slider&, int cx, int cy, int rad, const char* label);
    void drawFader(juce::Graphics&, juce::Slider&, int cx, int top, int bot);
    void drawHFader(juce::Graphics&, juce::Slider&, int left, int right, int cy);
    void drawCRT(juce::Graphics&, juce::Rectangle<int> area);
    EnsembleAudioProcessor& proc;
    juce::Slider blendK, tensionK, textureK, evolveK;
    juce::Slider persistK, inputK, dryK, outputK;
    juce::Slider eqSliders[12];
    juce::Slider resResoS, resMatS, resPitchS, resSpreadS, resWetS;
    juce::Slider eqWetS, bpFreqS;
    juce::ToggleButton bpToggle;
    juce::TextButton clearBtn;
    using SA = juce::AudioProcessorValueTreeState::SliderAttachment;
    using BA = juce::AudioProcessorValueTreeState::ButtonAttachment;
    std::unique_ptr<SA> blendA, tensionA, textureA, evolveA;
    std::unique_ptr<SA> persistA, inputA, dryA, outputA;
    std::unique_ptr<SA> eqA[12];
    std::unique_ptr<SA> resResoA, resMatA, resPitchA, resSpreadA, resWetA;
    std::unique_ptr<SA> eqWetA, bpFreqA;
    std::unique_ptr<BA> bpToggleA;
    static constexpr int TRACE = 256;
    float trL[TRACE]={}, trR[TRACE]={};
    int trPos = 0; float inLvl = 0.f;
    struct Pt { float x,y,vx,vy,life,dec,sz,brt; };
    static constexpr int NP = 150;
    Pt ps[NP] = {};
    int nxP = 0; float spAcc = 0.f; uint32_t rng = 12345;
    float fr(); void spawn(float e, float b); void tick(float dt);
    void mkRotary(juce::Slider&, std::unique_ptr<SA>&, const juce::String& pid);
    void mkLinear(juce::Slider&, std::unique_ptr<SA>&, const juce::String& pid);
    void mkHLinear(juce::Slider&, std::unique_ptr<SA>&, const juce::String& pid);
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(EnsembleAudioProcessorEditor)
};
